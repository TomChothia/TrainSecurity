#!/usr/bin/python3
  
##########################################################################
# trdp_include.py
# Thu  4 Jan 11:16:36 GMT 2024
################################################################################

import ipaddress
import json
import hashlib
import os
import pandas as pd
import pprint
import re
import socket
import sys
import textwrap
import zlib

from netaddr import IPNetwork, IPAddress
from range_key_dict import RangeKeyDict

##########################################################################
# constants
##########################################################################

# dataset length must always be at a byte boundary, i.e. a multiple of 8-
# bits
#
# dataset length must also be a multiple of DATASET_BYTES_MULTIPLES-bytes,
# i.e. 4-bytes (32-bits). if not, the dataset must be right-paded with
# bytes to ensure this multiple is reached
DATASET_BYTES_MULTIPLES = 4

# the largest unsigned int that can be held in 32-bits (4-bytes)
LARGEST_UINT32 = 4294967295
# the smallest unsigned int that can be held in 32-bits (4-bytes)
SMALLEST_UINT32 = 0

# the largest signed int that can be held in 32-bits (4-bytes)
LARGEST_INT32 = 2147483647
# the smallest signed int that can be held in 32-bits (4-bytes)
SMALLEST_INT32 = -2147483648 

# the maximum length of the pdu
PD_PDU_MAX_LENGTH_BYTES = 1472
PD_PDU_MAX_LENGTH_BITS = PD_PDU_MAX_LENGTH_BYTES * 8
MD_PDU_MAX_LENGTH_BYTES = 65504
MD_PDU_MAX_LENGTH_BITS = MD_PDU_MAX_LENGTH_BYTES * 8

# the minimum length of the pdu as defined in: IEC 61375-2-3:2015 (Hitachi Class 810)
STD_PD_PDU_MIN_LENGTH_BYTES = 44
STD_PD_PDU_MIN_LENGTH_BITS = STD_PD_PDU_MIN_LENGTH_BYTES * 8
STD_MD_PDU_MIN_LENGTH_BYTES = 120
STD_MD_PDU_MIN_LENGTH_BITS = STD_MD_PDU_MIN_LENGTH_BYTES * 8
#
# the minimum length of the pdu as defined in: Hitachi WCP TMS for AT300 Ethernet Communication Interface Specification (Hitachi Class 800-807)
DRAFT_PD_PDU_MIN_LENGTH_BYTES = 40
DRAFT_PD_PDU_MIN_LENGTH_BITS = DRAFT_PD_PDU_MIN_LENGTH_BYTES * 8
DRAFT_MD_PDU_MIN_LENGTH_BYTES = 116
DRAFT_MD_PDU_MIN_LENGTH_BITS = DRAFT_MD_PDU_MIN_LENGTH_BYTES * 8

# the maximum length of the dataset
PD_PDU_DATASET_MAX_LENGTH_BYTES = 1432
PD_PDU_DATASET_MAX_LENGTH_BITS  = PD_PDU_DATASET_MAX_LENGTH_BYTES * 8
MD_PDU_DATASET_MAX_LENGTH_BYTES = 65388
MD_PDU_DATASET_MAX_LENGTH_BITS  = MD_PDU_DATASET_MAX_LENGTH_BYTES * 8

# dictionary of trdp versions
trdpVersionDict = { 0 : "West Coast Partnership TMS for AT300 Ethernet Communication Interface Specification, Mito Works Drawing Number 365-3E857140, Hitachi Limited, 01/02/2021 (Hitachi Class 800-807)", 1 : "IEC 61375-2-3:2015 (Hitachi Class 810)"}

# IEC 61375-2-3:2015
#
# dictionary of comId descriptions (Appendix A.5, Table A.2 (pp124-126)
comIdDescDict = RangeKeyDict({(0,1): "unspecified PDU", (1,2): "ETBCTRL telegram", (2,3): "CSTINFO notification message", (3,4): "CSTINFOCTRL notification message", (4,10): "Additional ComIds reserved for communication framework and ETB control service", (10,11): "TRDP Echo", (11,30): "Additional ComIds reserved for communication framework and ETB control service", (30,31): "Additional ComIds reserved for TRDP statistics data", (31,32): "TRDP – statistics request command", (32,35): "Additional ComIds reserved for TRDP statistics data", (35,36): "TRDP – global statistics data", (36,37): "TRDP – subscription statistics data", (37,38): "TRDP – publishing statistics data", (38,39): "TRDP – redundancy statistics data", (39,40): "TRDP – join statistics data", (40,41): "TRDP- UDP listener statistics data", (41,42): "TRDP – TCP listener statistics data", (50,80): "Additional ComIds reserved for communication framework and ETB control service", (80,81): "Conformance test – control telegram", (81,82): "Conformance test – status telegram", (82,83): "Conformance test – confirmation request telegram", (83,84): "Conformance test – confirmation reply telegram", (84,85): "Conformance test – opTrnDir request telegram", (85,86): "Conformance test – opTrnDir reply telegram", (86,87): "Conformance test – echo request telegram", (87,88): "Conformance test – echo reply telegram", (88,89): "Conformance test – echo notification telegram", (89,100): "Additional ComIds reserved for conformance test", (100,101): "TTDB – operational train directory status telegram", (101,102): "TTDB – operational train directory notification", (102,103): "TTDB – train directory information request", (103,104): "TTDB – train directory information reply", (104,105): "TTDB – consist information request", (105,106): "TTDB – consist information reply", (106,107): "TTDB – train network directory information request", (107,108): "TTDB – train network directory information reply", (108,109): "TTDB – operational train directory information request", (109,110): "TTDB – operational train directory information reply", (110,111): "TTDB – train information complete request", (111,112): "TTDB – train information complete reply", (112,120): "Additional ComIds reserved for TTDB", (120,121): "ECSP – control telegram", (121,122): "ECSP – status telegram", (122,123): "ECSP – Confirmation/Correction request", (123,124): "ECSP – Confirmation/Correction reply", (124,130): "Additional ComIds reserved for ECSP", (130,131): "ETBN – control request", (131,132): "ETBN – status reply", (132,133): "ETBN – train network directory request", (133,134): "ETBN – train network directory reply", (134,140): "Additional ComIds reserved for ETBN", (140,141): "TCN-DNS – resolving request telegram (query)", (141,142): "TCN-DNS – resolving reply telegram", (142,150): "Additional ComIds reseraaved for TCN-DNS", (150,200): "Additional ComIds reserved for communication framework and ETB control service", (200,1000): "ComIds reserved for other standards and norms."})
#
# dictionary of msgType descriptions (pd: p133, md: p149)
msgTypeDescDict = { "5064" : "Pd: PD Data", "5065" : "Pe: PD Data (Error)", "5070" : "Pp: PD Reply", "5072" : "Pr: PD Request", "4d63" : "Mc: MD Confirm", "4d65" : "Me: MD error", "4d6e" : "Mn: MD Notification (Request without reply)", "4d70" : "Mp: MD Reply without confirmation", "4d71" : "Mq: MD Reply with confirmation", "4d72" : "Mr: MD Request with reply" }
#
# dictionary of md replyStatus descriptions (p150)
replyStatusDescDict = { -1 : "reserved/timeout", -2 : "session abort", -3 : "no replier instance (at replier side)", -4 : "no memory (at replier side)", -5 : "no memory (local)", -6 : "no reply", -7 : "not all replies", -8 : "no confirm", -9 : "reserved", -10 : "sending failed" }

# West Coast Partnership TMS for AT300 Ethernet Application Interface Specification, Mito Works Drawing Number 365-3E857141, Hitachi Limited, 01/02/2021.
# 3E857141Rv02_WCP_Ethernet_Application_Interface_Specification.pdf
#
# dictionary of Hitachi transmission lines (p7)
hitachiTransmissionLineDict = { 0 : "System 1", 1 : "System 2", 2 : "Spare", 3: "Spare" }
#
# dictionary of Hitachi unit network numbers (p7)
hitachiNetworkUnitNumberDict = { 0 : "First Unit", 1 : "Second Unit", 2 : "Third Unit", 3: "Forth Unit" }
#
# dictionary of Hitachi Device IDs used in the IP addressing architecture (pp7-9)
hitachiDeviceIdDict = { 6 : "Passenger Door Control Unit", 7 : "Gangway Door Control Unit", 20 : "TMS Router unit", 21 : "TMS Train controller", 23 : "TMS Monitoring server", 25 : "TMS Cab Interface Unit (Control System 1)", 26 : "TMS Cab Interface Unit (Control System 2)", 27 : "TMS Cab Interface Unit (Monitoring)", 28 : "TMS Vehicle Interface Unit (Control System 1)", 29 : "TMS Vehicle Interface Unit (Control System 2)", 30 : "TMS Vehicle Interface Unit (Monitoring)", 31 : "TMS Display Unit", 40 : "Traction", 44 : "BCU", 50 : "ETCS", 52 : "Vigilance", 59 : "OTMR", 60 : "APS", 67 : "Energy Meter", 78 : "OBS", 85 : "PIIS", 90 : "HVAC", 91 : "Cab HVAC", 92 : "Toilet (SST,UAT)", 94 : "Catering", 100 : "TMS Maintenance PC", 101 : "Common Data" }
#
# dictionary of Hitachi transmission lines and data types in multicast addresses (pp10)
hitachiTransmissionLineDataTypeDict = { 1 : "System 1 for Safety Data", 2 : "System 2 for Safety Data", 3 : "System 2 for Non-Safety Data" }
#
# dictionary of Hitachi frame types used in multicast addresses (pp10)
hitachiFrameTypeDict = { 1 : "Safety Data SDR (Short Period)", 2 : "Non-Safety Data SDR", 3 : "Safety Data SDR (Long Period)", 11 : "Safety Data SD (Short Period)", 12 : "Non-safety Data SD", 13 : "Safety Data SD (Long Period)", 34 : "Non-Safety Data SDR", 44 : "Non-Safety Data SD" }
#
# dictionary of Hitachi destination group types used in multicast addresses (pp11)
hitachiDestinationGroupTypeDict = RangeKeyDict({(1,10): "TMS: (1) TMS Train Controller; (2) TMS Monitoring Server; (3) TMS Display Unit", (10,20): "Apparatus in Leading Car: (1) TMS Cab I/F Unit; (2) OTMR; (3) Energy Meter; (4) Vigilance", (20,30): "Non TMS and Leading Car Apparatus: (1) Traction; (2) APS; (3) Toilet; (4) PIIS; (5) OBS; (6) Catering; (7) TMS Vehicle I/F Unit"})

# dictionary of Hitachi project codes
hitachiProjectCodeDict = { 0 : "Not Configured", 1 : "IEP (GWML)", 2 : "IEP (ECML)", 3 : "WoE", 4 : "TPE", 5 : "Hull", 6 : "ECOA", 7 : "WCP", 8 : "AEMR" }

##########################################################################
# calculate_num_dataset_padding_bytes
##########################################################################

def calculate_num_dataset_padding_bytes(dataset):

  # dataset: binary string

  # sanity check dataset
  if (not is_byte_sequence(dataset)):
    print(f"ERROR in function {sys._getframe().f_code.co_name}: invalid dataset, exiting.")
    exit(1)

  # calculate length of dataset
  datasetLength = int(len(dataset) / 8) # length of the dataset in bytes

  # the dataset length must be a multiple of DATASET_BYTE_MULTIPLES bytes. if not, it must be right-paded with full bytes (00000000) to ensure the multiple is reached

  # calculate the remainder
  datasetMod = datasetLength % DATASET_BYTES_MULTIPLES

  datasetNumBytesToAdd = 0
  if ((datasetLength < DATASET_BYTES_MULTIPLES) or (datasetMod != 0)):
    datasetNumBytesToAdd = DATASET_BYTES_MULTIPLES - datasetMod # number of bytes (00000000) to add as padding

  return datasetNumBytesToAdd

##########################################################################
# generate_dataset
##########################################################################

def generate_dataset(dataset):

  # dataset: binary string

  # sanity check dataset
  if (not is_byte_sequence(dataset)):
    print(f"ERROR in function {sys._getframe().f_code.co_name}: invalid dataset, exiting.")
    exit(1)

  # calculate the number of bytes to add as padding
  datasetNumBytesToAdd = calculate_num_dataset_padding_bytes(dataset)

  if (datasetNumBytesToAdd > 0):
    # original dataset must be padded
    # calculate the new dataset length including padding in bits (ljust requires bits)
    datasetNewLength = len(dataset) + (datasetNumBytesToAdd * 8) 
    # add the pading
    dataset = dataset.ljust(datasetNewLength, '0')

  return dataset, datasetNumBytesToAdd

##########################################################################
# generate_dataset_hex
##########################################################################

def generate_dataset_hex(dataset):

  # dataset: binary string

  # transform the dataset into hex, left-padding to ensure the leading 0 is present if required
  return hex(int(dataset, 2))[2:].zfill(int(len(dataset)/4))

##########################################################################
# generate_fcs
##########################################################################

def generate_fcs(data, trdp_version):

  # data: binary string (bits, not bytes)
  # trdp_version: the version of trdp (0 or 1) - required as byte order differs between versions

  # sanity check data
  if (not is_byte_sequence(data)):
    print(f"ERROR in function {sys._getframe().f_code.co_name}: invalid data, exiting.")
    exit(1)

  # convert the data into bytes (bytes are required by the crc32() function)
  pduHeaderBytes = bytes((int(data[i:i+8], 2) for i in range(0, len(data), 8)))

  # calculate the fcs (crc32)
  crc32Int = int(zlib.crc32(pduHeaderBytes))

  # for the pdu defined in IEC 61375-2-3:2015, the fcs32 must be in nbo
  if (trdp_version == 1):
    crc32Int = socket.htonl(crc32Int)

  crc32Hex = hex(crc32Int)[2:].zfill(8)
  crc32Bin = bin(crc32Int)[2:].zfill(32)

  return crc32Hex, crc32Bin

##########################################################################
# generate_fingerprint
##########################################################################

def generate_fingerprint(pduDict):

  # pduDict: the pduDict

  # data used to generate the fingerprint
  
  fingerprint = "sequenceCounterInt:" + str(pduDict['sequenceCounterInt']) + ","

  if ("topoCountInt" in pduDict.keys()):
    fingerprint = fingerprint + "topoCountInt:" + str(pduDict['topoCountInt']) + ","
  if ("etbTopoCntInt" in pduDict.keys()):
    fingerprint = fingerprint + "etbTopoCntInt:" + str(pduDict['etbTopoCntInt']) + ","
  if ("opTrnTopoCntInt" in pduDict.keys()):
    fingerprint = fingerprint + "opTrnTopoCntInt" + str(pduDict['opTrnTopoCntInt']) + ","
  if ("sessionIdStr" in pduDict.keys()):
    fingerprint = fingerprint + "sessionIdStr" + str(pduDict['sessionIdStr']) + ","

  #try:
  #  fingerprint = fingerprint + "transmissionLineDataTypeInt:" + str(pduDict['dstInetAddrDetails']['transmissionLineDataTypeInt']) + ","
  #except Exception:
  #  pass

  # remove the trailing ","
  fingerprint = fingerprint[:-1]

  # generate the fingerprint
  fingerprint = hashlib.md5(fingerprint.encode('utf-8')).hexdigest().lower()

  return fingerprint

##########################################################################
# generate_uri
##########################################################################

def generate_uri(string):

  # string: candidate string

  # calculate length of the string
  stringLength = len(string)

  # ensure the string is between 0-31 characters (bytes) in length (inclusive)
  if ((stringLength < 0) or (stringLength > 31)):
    print(f"ERROR in function {sys._getframe().f_code.co_name}: invalid string length, exiting.")
    exit(1)

  # convert the string into bytes
  stringBytes = bytes(string, 'ascii')

  # convert each byte into binary using zfill to ensure the leading zeros of each byte are preserved
  uri = (''.join(["{0:b}".format(x).zfill(8) for x in stringBytes]))

  # calculate the number of null bytes (00000000) to add to the string to make it up to 32-bytes in length (byte-32 must always be null)
  stringNumNullBytesToAdd = (32 - stringLength)

  # add the null byte padding
  nullBytePadding = "00000000"
  for x in range(1, stringNumNullBytesToAdd):
    nullBytePadding = nullBytePadding + "00000000"

  # assemble the final uri, with padding
  uri = uri + nullBytePadding

  return uri

##########################################################################
# get_desc
##########################################################################

def get_desc(dict, key):

  # dict: the dictionary
  # key: the dictionary key

  if (dict.get(key)):
    return dict.get(key)
  else:
    return "unknown"

##########################################################################
# is_byte_sequence
##########################################################################

def is_byte_sequence(binaryString):

  # binaryString: binary string

  binaryLength = len(binaryString)
  regex = "[01]{" + str(binaryLength) + "}"
  if ((re.match(regex, binaryString)) and (binaryLength >= 8) and (binaryLength % 8 == 0)): 
    return True
  else:
    return False

##########################################################################
# is_hex
##########################################################################

def is_hex(string):

  # string: candidate string

  try:
    int(string, 16)
    return True
  except ValueError:
    return False

##########################################################################
# is_uuid
##########################################################################

def is_uuid(hexString):

  # hexString: candidate string

  if ((is_hex(hexString)) and (len(hexString) == 32)):
    return True
  else:
    return False

##########################################################################
# length_bytes_to_bits
##########################################################################

def length_bytes_to_bits(length):

  # length: length in bytes

  return length, int(length * 8)

##########################################################################
# print_received_pdu_error
##########################################################################

def print_received_pdu_error(message):

  # message: the error message to be disaplayed

  print(f">>> PACKET RECEIVED: {message} <<<\n")

##########################################################################
# print_pdu
##########################################################################

def print_pdu(pduDict, verbose):

  # pduDict: the pduDict
  # verbose: append verbose output

  ##########################################################################
  # determine the length of the pdu in bytes
  ##########################################################################

  pduLengthBytes = int(pduDict['pduBinLength'] / 8)

  ##########################################################################
  # header
  ##########################################################################

  print(f">>> TRDP {pduDict['protocolName'].upper()} {pduDict['pduType'].upper()} PDU {pduDict['packetStatus'].upper()} {pduDict['srcInetAddr']}:{pduDict['srcPort']} -> {pduDict['dstInetAddr']}:{pduDict['dstPort']} (#{pduDict['packetCount']}) <<<")

  ##########################################################################
  # packetCount
  ##########################################################################

  if ("packetCount" in pduDict.keys()):
    print(f"    packetCount      = {pduDict['packetCount']}")

  ##########################################################################
  # sniffTime
  ##########################################################################

  if ("sniffTime" in pduDict.keys()):
    print(f"    sniffTime        = {pduDict['sniffTime']}")

  ##########################################################################
  # timestamp
  ##########################################################################

  if ("timestamp" in pduDict.keys()):
    print(f"    timestamp        = {pduDict['timestamp']}")

  ##########################################################################
  # fingerprint
  ##########################################################################

  if ("fingerprint" in pduDict.keys()):
    print(f"    fingerprint      = {pduDict['fingerprint']}", end="")

    if ("packetCount" in pduDict.keys()):
      print(f" | #{pduDict['packetCount']}", end="")

    if ("msgTypeDesc" in pduDict.keys()):
      print(f" | {pduDict['msgTypeDesc']}", end="")

    print("")

  ##########################################################################
  # lengths
  ##########################################################################

  if (pduDict['packetStatus'] == "received"):
    print(f"    lengths          =", end="")

    if ("ethernetFrameLength" in pduDict.keys()):
      ethernetFrameLengthBytes, ethernetFrameLengthBits = length_bytes_to_bits(pduDict['ethernetFrameLength'])
      print(f" Ethernet: {ethernetFrameLengthBytes}-bytes/{ethernetFrameLengthBits}-bits", end="")
    if ("ipPacketLength" in pduDict.keys()):
      ipPacketLengthBytes, ipPacketLengthBits = length_bytes_to_bits(pduDict['ipPacketLength'])
      print(f" | IP: {ipPacketLengthBytes}-bytes/{ipPacketLengthBits}-bits", end="")
    if ("udpPacketLength" in pduDict.keys()):
      udpPacketLengthBytes, udpPacketLengthBits = length_bytes_to_bits(pduDict['udpPacketLength'])
      print(f" | UDP: {udpPacketLengthBytes}-bytes/{udpPacketLengthBits}-bits", end="")
    if ("pduHexLength" in pduDict.keys()):
      pduHexLengthBytes, pduHexLengthBits = length_bytes_to_bits(pduDict['pduHexLength'])
      print(f" | TRDP: {pduHexLengthBytes}-bytes/{pduHexLengthBits}-bits", end="")

    print("")

  ##########################################################################
  # source ip address details
  ##########################################################################

  print("    ------------------------------------------------------------------")

  if ("srcMacAddr" in pduDict.keys()):
    print(f"    srcMacAddr       = {pduDict['srcMacAddr']}")
  if ("srcInetAddr" in pduDict.keys()):
    print(f"    srcInetAddr      = {pduDict['srcInetAddr']}")
  if ("srcPort" in pduDict.keys()):
    print(f"    srcPort          = {pduDict['srcPort']}")

  if ("srcInetAddrDetails" in pduDict.keys()):
    if ("trainInetAddrTransmissionLineInt" in pduDict['srcInetAddrDetails'].keys()):
      print(f"    transmissionLine = {pduDict['srcInetAddrDetails']['trainInetAddrTransmissionLineInt']} [{pduDict['srcInetAddrDetails']['trainInetAddrTransmissionLineDesc']}]")
    if ("trainInetAddrSubnetIdInt" in pduDict['srcInetAddrDetails'].keys()):
      print(f"    subnetId         = {pduDict['srcInetAddrDetails']['trainInetAddrSubnetIdInt']}")
    if ("trainInetAddrNetworkUnitNumberInt" in pduDict['srcInetAddrDetails'].keys()):
      print(f"    networkUnit      = {pduDict['srcInetAddrDetails']['trainInetAddrNetworkUnitNumberInt']} [{pduDict['srcInetAddrDetails']['trainInetAddrNetworkUnitNumberDesc']}]")
    if ("trainInetAddrVehicleIdInt" in pduDict['srcInetAddrDetails'].keys()):
      print(f"    vehicleId        = {pduDict['srcInetAddrDetails']['trainInetAddrVehicleIdInt']}")
    if ("trainInetAddrDeviceIdInt" in pduDict['srcInetAddrDetails'].keys()):
      print(f"    deviceId         = {pduDict['srcInetAddrDetails']['trainInetAddrDeviceIdInt']} [{pduDict['srcInetAddrDetails']['trainInetAddrDeviceIdDesc']}]")
    if ("transmissionLineDataTypeInt" in pduDict['srcInetAddrDetails'].keys()):
      print(f"    transmissionLine = {pduDict['srcInetAddrDetails']['transmissionLineDataTypeInt']} [{pduDict['srcInetAddrDetails']['transmissionLineDataTypeDesc']}]")
    if ("frameTypeInt" in pduDict['srcInetAddrDetails'].keys()):
      print(f"    frameType        = {pduDict['srcInetAddrDetails']['frameTypeInt']} [{pduDict['srcInetAddrDetails']['frameTypeDesc']}]")
    if ("destinationGroupTypeInt" in pduDict['srcInetAddrDetails'].keys()):
      print(f"    destinationGroup = {pduDict['srcInetAddrDetails']['destinationGroupTypeInt']} [{pduDict['srcInetAddrDetails']['destinationGroupTypeDesc']}]")

  ##########################################################################
  # destination ip address details
  ##########################################################################

  print("    ------------------------------------------------------------------")

  if ("dstMacAddr" in pduDict.keys()):
    print(f"    dstMacAddr       = {pduDict['dstMacAddr']}")
  if ("dstInetAddr" in pduDict.keys()):
    print(f"    dstInetAddr      = {pduDict['dstInetAddr']}")
  if ("dstInetAddr" in pduDict.keys()):
    print(f"    dstInetAddr      = {pduDict['dstInetAddr']}")
  if ("dstPort" in pduDict.keys()):
    print(f"    dstPort          = {pduDict['dstPort']}")

  if ("dstInetAddrDetails" in pduDict.keys()):
    if ("trainInetAddrTransmissionLineInt" in pduDict['dstInetAddrDetails'].keys()):
      print(f"    transmissionLine = {pduDict['dstInetAddrDetails']['trainInetAddrTransmissionLineInt']} [{pduDict['dstInetAddrDetails']['trainInetAddrTransmissionLineDesc']}]")
    if ("trainInetAddrSubnetIdInt" in pduDict['dstInetAddrDetails'].keys()):
      print(f"    subnetId         = {pduDict['dstInetAddrDetails']['trainInetAddrSubnetIdInt']}")
    if ("trainInetAddrNetworkUnitNumberInt" in pduDict['dstInetAddrDetails'].keys()):
      print(f"    networkUnit      = {pduDict['dstInetAddrDetails']['trainInetAddrNetworkUnitNumberInt']} [{pduDict['dstInetAddrDetails']['trainInetAddrNetworkUnitNumberDesc']}]")
    if ("trainInetAddrVehicleIdInt" in pduDict['dstInetAddrDetails'].keys()):
      print(f"    vehicleId        = {pduDict['dstInetAddrDetails']['trainInetAddrVehicleIdInt']}")
    if ("trainInetAddrDeviceIdInt" in pduDict['dstInetAddrDetails'].keys()):
      print(f"    deviceId         = {pduDict['dstInetAddrDetails']['trainInetAddrDeviceIdInt']} [{pduDict['dstInetAddrDetails']['trainInetAddrDeviceIdDesc']}]")
    if ("transmissionLineDataTypeInt" in pduDict['dstInetAddrDetails'].keys()):
      print(f"    transmissionLine = {pduDict['dstInetAddrDetails']['transmissionLineDataTypeInt']} [{pduDict['dstInetAddrDetails']['transmissionLineDataTypeDesc']}]")
    if ("frameTypeInt" in pduDict['dstInetAddrDetails'].keys()):
      print(f"    frameType        = {pduDict['dstInetAddrDetails']['frameTypeInt']} [{pduDict['dstInetAddrDetails']['frameTypeDesc']}]")
    if ("destinationGroupTypeInt" in pduDict['dstInetAddrDetails'].keys()):
      print(f"    destinationGroup = {pduDict['dstInetAddrDetails']['destinationGroupTypeInt']} [{pduDict['dstInetAddrDetails']['destinationGroupTypeDesc']}]")

  ##########################################################################
  # pdu is pd or md
  ##########################################################################

  if ((pduDict['pduType'] == "pd") or (pduDict['pduType'] == "md")):
    print("    ------------------------------------------------------------------")

    ##########################################################################
    # sequenceCounter
    ##########################################################################

    if ("sequenceCounterInt" in pduDict.keys()):
      print(f"    sequenceCounter  = {pduDict['sequenceCounterInt']}")

    ##########################################################################
    # protocolVersion
    ##########################################################################

    if ("protocolVersionStr" in pduDict.keys()):
      print(f"    protocolVersion  = {pduDict['protocolVersionStr']}")

    ##########################################################################
    # msgType
    ##########################################################################

    if ("msgTypeStr" in pduDict.keys()):
      print(f"    msgType          = {pduDict['msgTypeStr']}", end="")
      if ("msgTypeDesc" in pduDict.keys()):
        print(f" [{pduDict['msgTypeDesc']}]", end="")
    print("")

    ##########################################################################
    # comId
    ##########################################################################

    if ("comIdInt" in pduDict.keys()):
      print(f"    comId            = {pduDict['comIdInt']}", end="")
      if ("comIdDesc" in pduDict.keys()):
        print(f" [{pduDict['comIdDesc']}]", end="")
    print("")

    ##########################################################################
    # etbTopoCnt
    ##########################################################################

    if ("etbTopoCntInt" in pduDict.keys()):
      print(f"    etbTopoCnt       = {pduDict['etbTopoCntInt']}")

    ##########################################################################
    # opTrnTopoCnt
    ##########################################################################

    if ("opTrnTopoCntInt" in pduDict.keys()):
      print(f"    opTrnTopoCnt     = {pduDict['opTrnTopoCntInt']}")

    ##########################################################################
    # topoCount
    ##########################################################################

    if ("topoCountInt" in pduDict.keys()):
      print(f"    topoCount        = {pduDict['topoCountInt']}")

    ##########################################################################
    # datasetLength
    ##########################################################################

    # datasetLength
    if (pduDict['datasetLengthInt'] == 1):
      datasetLengthDesc = "byte"
    else:
      datasetLengthDesc = "bytes"
    datasetLengthBitsInt = int(pduDict['datasetLengthInt'] * 8)

    print(f"    datasetLength    = {pduDict['datasetLengthInt']}-{datasetLengthDesc}/{datasetLengthBitsInt}-bits", end="")

    if ("datasetPaddingLength" in pduDict.keys()):
      datasetPaddingBytes = pduDict['datasetPaddingLength']
      datasetPaddingBits = int(datasetPaddingBytes * 8)
      print(f" [{datasetPaddingBytes}-{datasetLengthDesc}/{datasetPaddingBits}-bits of padding]", end="")

    print("")

    ##########################################################################
    # reserved01
    ##########################################################################

    if ("reserved01Int" in pduDict.keys()):
      print(f"    reserved01       = {pduDict['reserved01Int']}")

    ##########################################################################
    # replyComId
    ##########################################################################

    if ("replyComIdInt" in pduDict.keys()):
      print(f"    replyComId       = {pduDict['replyComIdInt']}")

    ##########################################################################
    # replyIpAddress
    ##########################################################################

    if ("replyIpAddressStr" in pduDict.keys()):
      print(f"    replyIpAddress   = {pduDict['replyIpAddressStr']}")

    ##########################################################################
    # replyStatus
    ##########################################################################

    if ("replyStatusInt" in pduDict.keys()):
      print(f"    replyStatus      = {pduDict['replyStatusInt']}", end="")
      if ("replyStatusDesc" in pduDict.keys()):
        print(f" [{pduDict['replyStatusDesc']}]", end="")
      print("")

    ##########################################################################
    # sessionId
    ##########################################################################

    if ("sessionIdStr" in pduDict.keys()):
      sessionId = pduDict['sessionIdStr']
      sessionIdSubstrings = [sessionId[i:i + 8] for i in range(0, len(sessionId), 8)]
      print(f"    sessionId        = {sessionIdSubstrings[0]}-{sessionIdSubstrings[1]}-{sessionIdSubstrings[2]}-{sessionIdSubstrings[3]}")

    ##########################################################################
    # replyTimeout
    ##########################################################################

    if ("replyTimeoutInt" in pduDict.keys()):
      print(f"    replyTimeout     = {pduDict['replyTimeoutInt']}")

    ##########################################################################
    # sourceURI
    ##########################################################################

    if ("sourceURIStr" in pduDict.keys()):
      if (pduDict['sourceURIStr'] == ""):
        print(f"    sourceURI        = [empty]")
      else:
        print(f"    sourceURI        = {pduDict['sourceURIStr']}")

    ##########################################################################
    # destinationURI
    ##########################################################################

    if ("destinationURIStr" in pduDict.keys()):
      if (pduDict['destinationURIStr'] == ""):
        print(f"    destinationURI   = [empty]")
      else:
        print(f"    destinationURI   = {pduDict['destinationURIStr']}")

    ##########################################################################
    # fcs
    ##########################################################################

    if ("fcsHex" in pduDict.keys()):
      # the packet was sent or received
      if (pduDict['trdpVersion'] == 0):
        print(f"    fcs              = {pduDict['fcsHex']}", end="")
      elif (pduDict['trdpVersion'] == 1):
        print(f"    headerFcs        = {pduDict['fcsHex']}", end="")
      else:
        print(f"ERROR in function {sys._getframe().f_code.co_name}: invalid TRDP version, exiting.")
        exit(1)

    if ("fcsHex" in pduDict.keys()):
      # the packet was received
      if ("fcsValid" in pduDict.keys()):
        if(pduDict['fcsValid'] == True):
          fcsDesc = "valid"
        else:
          fcsDesc = "invalid"
        print(f" [{fcsDesc}]", end="")

    print("")

  ##########################################################################
  # dataset
  ##########################################################################

  # binary
  print("    ------------------------------------------------------------------")
  print("    dataset (binary) = ", end="")
  datasetWrapList = textwrap.wrap(pduDict['datasetStr'], 96)
  print('\n                       '.join(datasetWrapList))

  # hex
  print("                       -----------------------------------------------")
  if ("datasetHex" in pduDict.keys()):
    # the key exists: the packet was generated with a hex dataset, or read
    datasetHex = pduDict['datasetHex']
  else:
    # the key does not exist: the packet was generated with a binary dataset
    datasetHex = generate_dataset_hex(pduDict['datasetStr'])

  # add a space between every pair of hex numbers
  datasetHexStr = ""
  for x in range(0, len(datasetHex), 2):
    datasetHexStr = datasetHexStr + datasetHex[x:x+2] + " "

  # remove the trailing space
  datasetHexStr = datasetHexStr.strip().lower()

  print("    dataset (hex)    = ", end="")
  datasetHexWrapList = textwrap.wrap(datasetHexStr, 96)
  print('\n                       '.join(datasetHexWrapList))

  ##########################################################################
  # sdr details
  ##########################################################################

  if ("pdSdrDetails" in pduDict.keys()):
    print("    ------------------------------------------------------------------")
    print("    Status Data Request (SDR)")
    print("")
    pdSdrDetails = pduDict['pdSdrDetails']

    for key, value in pdSdrDetails.items():
      print(f"    {key:29} = {value}")

  ##########################################################################
  # trdp version specified by the user
  ##########################################################################

  print("    ------------------------------------------------------------------")
  print(f"    TRDP Version = {pduDict['trdpVersion']} : ", end="")
  trdpVersionWrapList = textwrap.wrap(pduDict['trdpVersionDesc'], 96)
  print("\n    ".join(trdpVersionWrapList) + "\n")

  ##########################################################################
  # verbose output, if required
  ##########################################################################

  if (verbose == True):
    pprintOutput = pprint.pformat(pduDict, indent=0, sort_dicts=True)
    pprintOutput = re.sub(r"(?m)\{|\}", "", pprintOutput) # remove dictionary {}
    pprintOutput = re.sub(r"(?m)'", "", pprintOutput)     # remove all '
    pprintOutput = re.sub(r"(?m),$", "", pprintOutput)    # remove trailing ,
    pprintOutput = re.sub(r"(?m)^", "    ", pprintOutput) # indent
    print(pprintOutput)

#################################################################################################
# process_hitachi_ip_address
#################################################################################################

def process_hitachi_ip_address(inetAddr):

  # inetAddr: binary string

  # results dict
  resultsDict = {}

  # ip address type
  resultsDict.update({'trainInetAddr' : inetAddr})
  resultsDict.update({'trainInetAddrValid' : False})
  resultsDict.update({'trainInetAddrType' : "invalid"})

  if (not validate_ip_address(inetAddr)):
    return resultsDict

  # split the inet addr string into quads
  inetAddrStr = inetAddr.split('.')

  # store the quads as ints
  inetAddrInt1 = int(inetAddrStr[0])
  inetAddrInt2 = int(inetAddrStr[1])
  inetAddrInt3 = int(inetAddrStr[2])
  inetAddrInt4 = int(inetAddrStr[3])

  if (inetAddrInt1 == 10):
    # this is a tcn ip address
    resultsDict.update({'trainInetAddrValid' : True})
    resultsDict.update({'trainInetAddrType'  : "unicast"})
  elif (inetAddrInt1 == 239):
    # this is a multicast tcn ip address
    resultsDict.update({'trainInetAddrValid' : True})
    resultsDict.update({'trainInetAddrType'  : "multicast"})
  else: 
    # this is not a tcn ip address
    return resultsDict

  # store the quads as 8-bit binary strings
  inetAddrBin1 = bin(inetAddrInt1)[2:].zfill(8)
  inetAddrBin2 = bin(inetAddrInt2)[2:].zfill(8)
  inetAddrBin3 = bin(inetAddrInt3)[2:].zfill(8)
  inetAddrBin4 = bin(inetAddrInt4)[2:].zfill(8)

  # assemble the ip address as a single binary string
  resultsDict.update({'trainInetAddrBin'  : inetAddrBin1 + inetAddrBin2 + inetAddrBin3 + inetAddrBin4})
 
  ############################################################################
  # process the ip address
  ############################################################################

  if (inetAddrInt1 == 10):

    ############################################################################
    # check whether the ip address is on the backbone
    ############################################################################

    if ((IPAddress(inetAddr) in IPNetwork("10.128.0.0/18")) or \
        (IPAddress(inetAddr) in IPNetwork("10.160.0.0/18")) or \
        (IPAddress(inetAddr) in IPNetwork("10.192.0.0/18")) or \
        (IPAddress(inetAddr) in IPNetwork("10.224.0.0/18"))):
      isBackboneInetAddr = True
      resultsDict.update({'trainInetAddrLocation'  : "backbone"})
    else:
      isBackboneInetAddr = False
      resultsDict.update({'trainInetAddrLocation'  : "consist"})

    ############################################################################
    # tcn ip address
    ############################################################################

    ############################################################################
    # bits 9-10: transmission line
    ############################################################################

    transmissionLineBin = ""
    for i in range(9,11,1):
      transmissionLineBin = transmissionLineBin + str(resultsDict['trainInetAddrBin'][i])
    transmissionLineInt = int(transmissionLineBin, 2)
    transmissionLineDesc = get_desc(hitachiTransmissionLineDict, transmissionLineInt)
    resultsDict.update({'trainInetAddrTransmissionLineInt'  : transmissionLineInt})
    resultsDict.update({'trainInetAddrTransmissionLineDesc' : transmissionLineDesc})

    ############################################################################
    # bits 12-13: network unit number
    ############################################################################

    networkUnitNumberBin = ""
    for i in range(12,14,1):
      networkUnitNumberBin = networkUnitNumberBin + str(resultsDict['trainInetAddrBin'][i])
    networkUnitNumberInt = int(networkUnitNumberBin, 2)
    networkUnitNumberDesc = get_desc(hitachiNetworkUnitNumberDict, networkUnitNumberInt)
    resultsDict.update({'trainInetAddrNetworkUnitNumberInt'  : networkUnitNumberInt})
    resultsDict.update({'trainInetAddrNetworkUnitNumberDesc' : networkUnitNumberDesc})

    ############################################################################
    # bits 14-17: vehicle id
    ############################################################################

    vehicleIdBin = ""
    for i in range(14,18,1):
      vehicleIdBin = vehicleIdBin + str(resultsDict['trainInetAddrBin'][i])
    vehicleIdInt = int(vehicleIdBin, 2)
    resultsDict.update({'trainInetAddrVehicleIdInt' : vehicleIdInt})

    ############################################################################
    # bits 12-17: subnet id
    ############################################################################

    subnetIdBin = ""
    for i in range(12,18,1):
      subnetIdBin = subnetIdBin + str(resultsDict['trainInetAddrBin'][i])
    subnetIdInt = int(subnetIdBin, 2)
    resultsDict.update({'trainInetAddrSubnetIdInt' : subnetIdInt})

    ############################################################################
    # bits 24-31: device id
    ############################################################################

    if (isBackboneInetAddr == False):
      deviceIdBin = ""
      for i in range(24,32,1):
        deviceIdBin = deviceIdBin + str(resultsDict['trainInetAddrBin'][i])
      deviceIdInt = int(deviceIdBin, 2)
      deviceIdDesc = get_desc(hitachiDeviceIdDict, deviceIdInt)
      resultsDict.update({'trainInetAddrDeviceIdInt'  : deviceIdInt})
      resultsDict.update({'trainInetAddrDeviceIdDesc' : deviceIdDesc})

  elif (inetAddrInt1 == 239):

    ############################################################################
    # multicast tcn ip address
    ############################################################################

    resultsDict.update({'trainInetAddrLocation'  : "multicast"})

    ############################################################################
    # bits 13-15: transmission line and data type
    ############################################################################

    transmissionLineDataTypeBin = ""
    for i in range(13,16,1):
      transmissionLineDataTypeBin = transmissionLineDataTypeBin + str(resultsDict['trainInetAddrBin'][i])
    transmissionLineDataTypeInt = int(transmissionLineDataTypeBin, 2)
    transmissionLineDataTypeDesc = get_desc(hitachiTransmissionLineDataTypeDict, transmissionLineDataTypeInt)
    resultsDict.update({'transmissionLineDataTypeInt'  : transmissionLineDataTypeInt})
    resultsDict.update({'transmissionLineDataTypeDesc' : transmissionLineDataTypeDesc})

    ############################################################################
    # bits 16-23: frame type
    ############################################################################

    frameTypeBin = ""
    for i in range(16,24,1):
      frameTypeBin = frameTypeBin + str(resultsDict['trainInetAddrBin'][i])
    frameTypeInt = int(frameTypeBin, 2)
    frameTypeDesc = get_desc(hitachiFrameTypeDict, frameTypeInt)
    resultsDict.update({'frameTypeInt' : frameTypeInt})
    resultsDict.update({'frameTypeDesc' : frameTypeDesc})

    ############################################################################
    # bits 24-31: destination group type
    ############################################################################

    destinationGroupTypeBin = ""
    for i in range(24,32,1):
      destinationGroupTypeBin = destinationGroupTypeBin + str(resultsDict['trainInetAddrBin'][i])
    destinationGroupTypeInt = int(destinationGroupTypeBin, 2)
    destinationGroupTypeDesc = get_desc(hitachiDestinationGroupTypeDict, destinationGroupTypeInt)
    resultsDict.update({'destinationGroupTypeInt'  : destinationGroupTypeInt})
    resultsDict.update({'destinationGroupTypeDesc' : destinationGroupTypeDesc})

  ############################################################################
  # return the result dictionary
  ############################################################################

  return resultsDict

#################################################################################################
# process_hitachi_pd_sdr
#################################################################################################

def process_hitachi_pd_sdr(dataset, pdSdrType):

  # dataset: binary string
  # pdSdrType: 0==safety; 1==non-safety

  # results dict
  resultsDict = {}

  # ensure the dataset is of a valid length (contains at least Common Data)
  commonDataLengthBits = len(dataset)
  commonDataLengthBytes = int(commonDataLengthBits / 8)

  if ((commonDataLengthBits < 384) or (not is_byte_sequence(dataset))):
    # 384 is the minimum length of the Common Data (in bits)
    resultsDict.update({'pdSdrTypeDesc' : "Invalid Common Data length (" + str(commonDataLengthBytes) + "-bytes/" + str(commonDataLengthBits) + "-bits)"})
    return resultsDict

  destinationDeviceIdInt = int(dataset[0:8], 2)

  if (destinationDeviceIdInt != 255):
    resultsDict.update({'pdSdrTypeDesc' : "Destination Device ID of Common Data must be 255 (" + str(destinationDeviceIdInt) + ")"})
    return resultsDict

  #################################################################################################
  # Common Data for: CSV-SDR1 (Safety)
  #                  MLC-SDR1, MLV-SDR1, MLV-SDR3 (Non-Safety)
  #################################################################################################

  resultsDict.update({"------ SDR COMMON DATA ------" : "----------------------------------"})
  resultsDict.update({'destinationDeviceIdInt' : destinationDeviceIdInt})
  resultsDict.update({'destinationDeviceIdDesc' : "Destination Device ID of Common Data must be 255"})

  resultsDict.update({'projectCodeInt' : int(dataset[8:16], 2)})
  resultsDict.update({'projectCodeDesc' : get_desc(hitachiProjectCodeDict, resultsDict['projectCodeInt'])})

  yearTens   = int(dataset[160:164], 2)
  yearUnits  = int(dataset[164:168], 2)
  monthTens  = int(dataset[168:172], 2)
  monthUnits = int(dataset[172:176], 2)
  dayTens    = int(dataset[176:180], 2)
  dayUnits   = int(dataset[180:184], 2)
  resultsDict.update({'date' : str(dayTens) + str(dayUnits) + "/" + str(monthTens) + str(monthUnits) + "/" + str(yearTens) + str(yearUnits)})

  hourTens     = int(dataset[184:188], 2)
  hourUnits    = int(dataset[188:192], 2)
  minutesTens  = int(dataset[192:196], 2)
  minutesUnits = int(dataset[196:200], 2)
  secondsTens  = int(dataset[200:204], 2)
  secondsUnits = int(dataset[204:208], 2)
  resultsDict.update({'time' : str(hourTens) + str(hourUnits) + ":" + str(minutesTens) + str(minutesUnits) + ":" + str(secondsTens) + str(secondsUnits)})

  resultsDict.update({'couplingUncouplingPrediction' : dataset[208]})
  resultsDict.update({'dateTimeCorrection' : dataset[215]})

  if (pdSdrType == 0):

    #################################################################################################
    # Common Data (Safety) for: CSV-SDR1: 239.1.1.20 (System 1)
    #                           CSV-SDR1: 239.2.1.20 (System 2)
    #################################################################################################

    resultsDict.update({'pdSdrTypeDesc' : "Common Data (Safety) for CSV-SDR1 239.1.1.20 (System 1), CSV-SDR1 239.2.1.20 (System 2)"})

    resultsDict.update({'dataLengthInt' : int(dataset[16:32], 2)})
    resultsDict.update({'dataLengthDesc' : "Length of Common Data must be 44 bytes (bytes 4-47)"})

    resultsDict.update({'cabOnEndCarOfOtherSize' : dataset[224]})
    resultsDict.update({'cabOnEndCarOfVS1' : dataset[225]})
    resultsDict.update({'slowSpeedMode' : dataset[226]})
    resultsDict.update({'hillStartMode' : dataset[227]})
    resultsDict.update({'ddsPositionReverse' : dataset[230]})
    resultsDict.update({'ddsPositionForward' : dataset[231]})
    resultsDict.update({'changoverInProgress' : dataset[233]})
    resultsDict.update({'changoverCompleted' : dataset[234]})
    resultsDict.update({'constantSpeedBraking' : dataset[235]})
    resultsDict.update({'constantSpeedPowering' : dataset[236]})
    resultsDict.update({'speedLimitActive' : dataset[237]})
    resultsDict.update({'powering' : dataset[238]})
    resultsDict.update({'braking' : dataset[239]})

    resultsDict.update({'firstUnitTrainTypeElectric' : dataset[256]})
    resultsDict.update({'firstUnitTrainTypeBiMode' : dataset[257]})
    resultsDict.update({'firstUnitLocomotiveHauledMode' : dataset[258]})
    resultsDict.update({'firstUnitRescueMode' : dataset[261]})
    resultsDict.update({'firstUnitPowerType' : dataset[262]})

    resultsDict.update({'numCarsNetworkUnitFirst'  : int(dataset[288:296], 2)})
    resultsDict.update({'numCarsNetworkUnitSecond' : int(dataset[296:304], 2)})

    resultsDict.update({'trainSpeed' : int(dataset[320:336], 2)})
    resultsDict.update({'trainSpeedDifference' : int(dataset[336:352], 2)})
    resultsDict.update({'tractiveEffort' : int(dataset[352:368], 2)})
    resultsDict.update({'brakeEffort' : int(dataset[368:384], 2)})

  #################################################################################################
  # apparatus data
  #################################################################################################

  # count the number of apparatus included in the dataset
  apparusCount = 1

  # the apparatus data
  apparatusData = dataset[384:]

  while (len(apparatusData) >= 32):
    # loop until there is no remaining apparatus data

    # dictionary
    resultsDict.update({"-------- APPARATUS " + str(apparusCount) + " --------" : "----------------------------------"})
 
    # extract the headers
    apparatusDeviceIdInt = int(apparatusData[0:8], 2)
    apparatusDeviceIdDesc = get_desc(hitachiDeviceIdDict, apparatusDeviceIdInt)
    apparatusDataLengthBytes = int(apparatusData[16:32], 2)
    apparatusDataLengthBits = apparatusDataLengthBytes * 8

    # extract the data
    apparatusDataBin = apparatusData[32:(32+apparatusDataLengthBits)]
    apparatusDataHex = generate_dataset_hex(apparatusDataBin)

    # add a space between every pair of hex numbers
    apparatusDataHexStr = ""
    for x in range(0, len(apparatusDataHex), 2):
      apparatusDataHexStr = apparatusDataHexStr + apparatusDataHex[x:x+2] + " "

    # remove the trailing space
    apparatusDataHexStr = apparatusDataHexStr.strip().lower()

    # format for printing
    apparatusDataHexWrapList = textwrap.wrap(apparatusDataHexStr, 96)
    apparatusDataHexPrint = '\n                                    '.join(apparatusDataHexWrapList)

    resultsDict.update({'apparatus' + str(apparusCount) + "_deviceIdInt" : apparatusDeviceIdInt})
    resultsDict.update({'apparatus' + str(apparusCount) + "_deviceIdDesc" :  apparatusDeviceIdDesc})
    resultsDict.update({'apparatus' + str(apparusCount) + "_headerLengthBytes" : 4})
    resultsDict.update({'apparatus' + str(apparusCount) + "_headerLengthBits" : 32})
    resultsDict.update({'apparatus' + str(apparusCount) + "_dataLengthBytes" : apparatusDataLengthBytes})
    resultsDict.update({'apparatus' + str(apparusCount) + "_dataLengthBits" : apparatusDataLengthBits})
    resultsDict.update({'apparatus' + str(apparusCount) + "_data" : apparatusDataHexPrint})

    # generate the remaining apparatus data (remove the current apparatus headers/data)
    apparatusData = apparatusData[(32+apparatusDataLengthBits):]

    # increment the counter and repeat the while loop
    apparusCount += 1

  return resultsDict

##########################################################################
# validate_ip_address
##########################################################################

def validate_ip_address(inetAddr):

  # inetAddr: an ipv4 address

  try:
    inetAddrObject = ipaddress.ip_address(inetAddr)
    return True
  except ValueError:
    return False

##########################################################################
# validate_mac_address
##########################################################################

def validate_mac_address(macAddr):
 
  # macAddr: mac address

  regex = ("^([0-9A-Fa-f]{2}[:-])" + "{5}([0-9A-Fa-f]{2})|" + "([0-9a-fA-F]{4}\\." + "[0-9a-fA-F]{4}\\." + "[0-9a-fA-F]{4})$")
  regexCompiled = re.compile(regex)
 
  if (re.search(regexCompiled, macAddr)):
    return True
  else:
    return False

##########################################################################
# validate_port
##########################################################################

def validate_port(port):

  # port: tcp/udp port number

  if ((port > 0) and (port <= 65535)):
    return True
  else:
    return False

##########################################################################
# write_txt_output_files
##########################################################################

def write_txt_output_files(pduDict, filename):

  # pduDict: the pduDict

  if ("pduType" in pduDict.keys()):
    pduType = pduDict['pduType']
  else:
    print(f"ERROR in function {sys._getframe().f_code.co_name}: cannot determine pduType, exiting.")
    exit(1)

  # json
  jsonFileName = filename + "_" + pduType + ".json"
  jsonFileHandle = open(jsonFileName, 'a')
  jsonObject = json.dumps(pduDict, indent=2, sort_keys=False, default=str) + "\n"
  jsonFileHandle.write(jsonObject)
  jsonFileHandle.close()

  # csv
  csvFileName = filename + "_" + pduType + ".csv"
  dataFrame = pd.json_normalize(pduDict)
  csvHeaderRequired = False
  if (not os.path.isfile(csvFileName)):
    csvHeaderRequired = True
  dataFrame.to_csv(path_or_buf=csvFileName, header=csvHeaderRequired, index=False, mode="a")

##########################################################################
# end
##########################################################################
