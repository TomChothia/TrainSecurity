#!/usr/bin/python3

##########################################################################
# trdp.py
#
# Version: 2.19
#
#
# Generate a TRDP PDU.
#
# PD Protocol: UDP
# PD Port:     17224
# Reference :  Appendix A.6 Process Data (p126)
# Packet:      Figure A.11 (p132)
#
# MD Protocol: UDP / TCP
# MD Port:     17225 (UDP) / 17226 (TCP)
# Reference:   Appendix A.7 Message Data (p146)
# Packet:      Figure A.19 (p148)
#
# Packet format  defined in:
#
# BS EN 61375-2-3:2015+A11:2017 Electronic railway equipment -
# Train communication network (TCN). Part 2-3 TCN communication profile
# (IEC 61375-2-3:2015).
# BS EN 61375-2-3-2015+A11-2017--[2023-06-30--06-08-39 PM].pdf
#
# And:
#
# West Coast Partnership TMS for AT300 Ethernet Communication Interface
# Specification, Mito Works Drawing Number 365-3E857140, Hitachi Limited,
# 01/02/2021.
# 3E857140Rv01_WCP_Ethernet_Communication_Interface_Specification.pdf
#
# python3 modules dependencies:
#
#   pip3 install argparse bitstring datetime hashlib ipaddress netaddr
#                pandas range_key_dict scapy uuid 
#
##########################################################################

import argparse
import ipaddress
import re
import socket
import time
import uuid

from scapy.all import *
from scapy.config import conf

from trdp_include import *

##########################################################################
# ensure the user has root privileges
##########################################################################

if (os.geteuid() != 0):
  print("ERROR: you need root privileges to run this script, exiting.")
  exit(1)

##########################################################################
# parse arguments
##########################################################################

# create parsers
parser = argparse.ArgumentParser(description="Generate a valid TRDP PDU.") 
parentParser = argparse.ArgumentParser()

# add arguments to parentParser
parentParser.add_argument("dstInetAddr", type=str, help="Destination IP address.")
parentParser.add_argument("-v", "--verbose", default=False, required=False, action="store_true", help="Increase output verbosity.")
parentParser.add_argument("-dp", "--dstPort", type=int, required=False, help="Destination port. Range: 1-65535. Default: 17224/UDP (PD); 17225/UDP (MD).") # default is dependent on pdu type and transport protocol, so is calculated below
parentParser.add_argument("-sa", "--srcInetAddr", type=str, required=False, default="127.0.0.1", help="Source IP address (UDP only). Default: 127.0.0.1.") 
parentParser.add_argument("-sp", "--srcPort", type=int, required=False, help="Source port (UDP only). Range: 1-65535. Default: random 49152<=n<=65535.") # default is a random number, so is calculated below
parentParser.add_argument("-sm", "--srcMacAddr", type=str, required=False, help="Source MAC address. Default: mac address assigned to default interface.") # default is taken from the default interface, so is calculated below
parentParser.add_argument("-t",  "--trdpVersion", type=int, required=False, default=1, help="TRDP version. Valid: 0 (Hitachi WCP TMS for AT300 365-3E857140, Hitachi Class 800-807); 1 (IEC 61375-2-3:2015, Hitachi Class 810). Default: 1.")
parentParser.add_argument("-ds", "--datasetBin", type=str, required=False, default="10101010", help="Set dataset in binary. Valid: binary string of bits (byte-length). Default: 10101010.") 
parentParser.add_argument("-dx", "--datasetHex", type=str, required=False, help="Set dataset in hex. Valid: string of hex (byte-length).") 
parentParser.add_argument("-sc", "--sequenceCounter", type=int, required=False, default=0, help="Set sequenceCounter. Range: 0-4294967295. Default: 0.")
parentParser.add_argument("-pv", "--protocolVersion", type=float, required=False, default=1.0, help="Set protocolVersion. Range n.n, where 0<=n<=255. Default: 1.0.")
parentParser.add_argument("-ci", "--comId", type=int, required=False, default=0, help="Set comId. Range: 0-4294967295 (see IEC 61375-2-3:2015, Appendix A.5, Table A.2 (pp124-126). Default: 0.") 
parentParser.add_argument("-ec", "--etbTopoCnt", type=int, required=False, default=0, help="Set etbTopoCnt (TRDP version 1 only). Range: 0-4294967295. Default: 0.") 
parentParser.add_argument("-oc", "--opTrnTopoCnt", type=int, required=False, default=0, help="Set opTrnTopoCnt (TRDP version 1 only). Range: 0-4294967295. Default: 0.") 
parentParser.add_argument("-tc", "--topoCount", type=int, required=False, default=0, help="Set topoCount (TRDP version 0 only). Range: 0-4294967295. Default: 0.") 

# create sub parser
subparsers = parser.add_subparsers(help='PDU type.', dest='cmd')

# add arguments to pd sub parser
pd_parser = subparsers.add_parser('pd', parents=[parentParser], add_help=False)
pd_parser.add_argument("-mp", "--msgTypePd", type=str.lower, required=False, default="5072", help="Set msgType. Valid: 5064 (Pd: PD Data); 5065 (Pe: PD Data Error); 5070 (Pp: PD Reply); 5072 (Pr: PD Request). Default: 5072.")
pd_parser.add_argument("-rc", "--replyComId", type=int, required=False, default=0, help="Set replyComId (TRDP version 1 only). Range: 0-4294967295. Default: 0.") 
pd_parser.add_argument("-ra", "--replyIpAddress", type=str, required=False, default="0.0.0.0", help="Set replyIpAddress. Valid: IPv4 address. Default: 0.0.0.0") 
# add arguments to md sub parser
md_parser = subparsers.add_parser('md', parents=[parentParser], add_help=False)
md_parser.add_argument("-pr", "--protocol", type=str.lower, required=False, help="Set protocol. Valid: udp; tcp. Default: udp.") # default is dependent on pdu type and linked to dstPort, so is calculated with dstPort below
md_parser.add_argument("-mm", "--msgTypeMd", type=str.lower, required=False, default="4d6e", help="Set msgType. Valid: 4d63 (Mc: MD Confirm); 4d65 (Me: MD Error); 4d6e (Mn: MD Notification, request without reply); 4d70 (Mp: MD Reply, without confirmation); 4d71 (Mq: MD Reply, with confirmation); 4d72 (Mr: MD Request, with reply). Default: 4d6e.")
md_parser.add_argument("-rs", "--replyStatus", type=int, required=False, default=0, help="Set replyStatus. Range: -2147483648 to 2147483647. Default: 0 (OK).")
md_parser.add_argument("-si", "--sessionId", type=str.lower, required=False, help="Set sessionId. Valid: 32-character hexadecimal string (RFC-4122 UUID). Default: locally-generated time-based UUID.") # default requires a random hex number, so is calculated below
md_parser.add_argument("-rt", "--replyTimeout", type=int, required=False, default=0, help="Set replyTimeout. Range: 0-4294967295. Default: 0 (infinite).")
md_parser.add_argument("-su", "--sourceURI", type=str, required=False, default="", help="Set sourceURI. Valid: 0-31 characters. Default: empty string.")
md_parser.add_argument("-du", "--destinationURI", type=str, required=False, default="", help="Set destinationURI. Valid: 0-31 characters. Default: empty string.")

# retrieve args 
args = parser.parse_args(args=(sys.argv[1:] or ['--help']))

##########################################################################
# constants
##########################################################################

# the pdu type to be generated
pduType = args.cmd.lower()

##########################################################################
# dictionaries
##########################################################################

# pdu dictionary: contains data required to constuct the final pdu
pduDict = {}

# initial values
pduDict.update({'packetCount'  : 1})
pduDict.update({'packetStatus' : "sent"})

##########################################################################
# dstInetAddr: the destination ip address of the pdu
# pduType: pd/md
##########################################################################

if (validate_ip_address(args.dstInetAddr)):
  # dictionary
  pduDict.update({'dstInetAddr' : args.dstInetAddr})
else:
  print("ERROR: invalid dstInetAddr, exiting.")
  exit(1)

##########################################################################
# dstPort: the destination port of the pdu
# pduType: pd/md
#
# protocol: pdu protocol transport
# pduType: md
##########################################################################

# default protocol for pd/md
protocol = "udp"

# set default dstPort and protocol
if (pduType == "pd"):
  # pd default value: 17224 (UDP)
  dstPort = 17224
  # protocol is always udp
elif (pduType == "md"):
  # md default value: 17225 (UDP)
  dstPort = 17225
  # update protocol, if set
  if (args.protocol):
    if (args.protocol == "udp"):
      protocol = "udp"
    elif (args.protocol == "tcp"):
      protocol = "tcp"
    else:
      print("ERROR: invalid protocol, exiting.")
      exit(1)
else:
  print("ERROR: internal error at args.dstPort, exiting.")
  exit(1)

# update dstPort, if set
if (args.dstPort):
  if (validate_port(args.dstPort)):
    dstPort = args.dstPort
  else:
    print("ERROR: invalid dstPort, exiting.")
    exit(1)

# dictionary
pduDict.update({'dstPort'      : dstPort})
pduDict.update({'protocolName' : protocol})
pduDict.update({'pduType'      : pduType})

##########################################################################
# srcInetAddr: the source ip address of the pdu
# pduType: pd/md
##########################################################################

if (validate_ip_address(args.srcInetAddr)):
  # dictionary
  pduDict.update({'srcInetAddr' : args.srcInetAddr})
else:
  print("ERROR: invalid srcInetAddr, exiting.")
  exit(1)

##########################################################################
# srcPort: the source port of the pdu
# pduType: pd/md
##########################################################################

if (args.srcPort):
  if (validate_port(args.srcPort)):
    srcPort = args.srcPort
  else:
    print("ERROR: invalid srcPort, exiting.")
    exit(1)
else:
  srcPort = random.randrange(49152, 65536)

# dictionary
pduDict.update({'srcPort' : srcPort})

##########################################################################
# srcMacAddr: the source mac address of the pdu
# pduType: pd/md
##########################################################################

if (args.srcMacAddr):
  if (validate_mac_address(args.srcMacAddr)):
    srcMacAddr = args.srcMacAddr
  else:
    print("ERROR: invalid srcMacAddr, exiting.")
    exit(1)
else:
  srcMacAddr = Ether().src

# dictionary
pduDict.update({'srcMacAddr' : srcMacAddr.upper()})

##########################################################################
# trdpVersion: the version of the trdp pdu
# pduType: pd/md
##########################################################################

if ((args.trdpVersion >= 0) and (args.trdpVersion <= 1)):
  # dictionary
  pduDict.update({'trdpVersion'     : args.trdpVersion})
  pduDict.update({'trdpVersionDesc' : get_desc(trdpVersionDict, pduDict['trdpVersion'])})
else:
  print(f"ERROR: invalid TRDP version, exiting.")
  exit(1)

##########################################################################
# datasetHex: user data set UINT8[datasetLength] in hex
# pduType: pd/md
##########################################################################

# if datasetHex has been set, over-ride the binary dataset default or user
# specified value (i.e. update args.datasetBin)

if (args.datasetHex):
  if (not is_hex(args.datasetHex)):
    print("ERROR: invalid dataset, exiting.")
    exit(1)
  else:

    # the hex value
    datasetHex = args.datasetHex.lower()
    #
    # if the length of datasetHex is odd: add a leading 0 (hex)
    if (len(datasetHex) % 2 == 1):
      datasetHex = "0" + datasetHex

    # the binary value
    #
    # deal with leading 0's in the hex string: calculate the required length of the binary string
    requiredLengthofDatasetBin = len(datasetHex) * 4
    #
    # update args.datasetBin (used below), left-padding with 0s to the required length of the dataset
    args.datasetBin = bin(int(datasetHex, 16))[2:].zfill(requiredLengthofDatasetBin)

    # dictionary
    pduDict.update({'datasetHex' : datasetHex})
    pduDict.update({'datasetHex' : datasetHex})

##########################################################################
# dataset: user data set UINT8[datasetLength] in binary
# pduType: pd/md
##########################################################################

if ((is_byte_sequence(args.datasetBin)) and (len(args.datasetBin) <= PD_PDU_DATASET_MAX_LENGTH_BITS)):
  # dictionary
  datasetStr = args.datasetBin
  pduDict.update({'datasetStr' : datasetStr})
else:
  print("ERROR: invalid dataset, exiting.")
  exit(1)

##########################################################################
# sequenceCounter: message sequence counter (UINT32)
# pduType: pd/md
##########################################################################

if ((args.sequenceCounter >= SMALLEST_UINT32) and (args.sequenceCounter <= LARGEST_UINT32)):
  sequenceCounterBin = bin(args.sequenceCounter)[2:].zfill(32)
  # dictionary
  pduDict.update({'sequenceCounterInt' : args.sequenceCounter})
  pduDict.update({'sequenceCounterBin' : sequenceCounterBin})
else:
  print("ERROR: invalid SequenceCounter, exiting.")
  exit(1)

##########################################################################
# protocolVersion: protocol version (UINT16)
# pduType: pd/md
##########################################################################

# convert the float into a string
protocolVersionStr = str(args.protocolVersion)

# split the spring into main and sub protocol version numbers
protocolVersionSplit = protocolVersionStr.split('.')
protocolVersionMain = int(protocolVersionSplit[0])
protocolVersionSub = int(protocolVersionSplit[1])

# sanity check the protocolVersion
if ((protocolVersionMain >= 0) and (protocolVersionMain <= 255) and (protocolVersionSub >= 0) and (protocolVersionSub <= 255)):
  protocolVersionHex = str(hex(protocolVersionMain))[2:].zfill(2) + str(hex(protocolVersionSub))[2:].zfill(2)
  protocolVersionInt = int(protocolVersionHex, 16)
  protocolVersionBin = bin(protocolVersionInt)[2:].zfill(16)
  # dictionary
  pduDict.update({'protocolVersionStr' : protocolVersionStr})
  pduDict.update({'protocolVersionBin' : protocolVersionBin})
else:
  print("ERROR: invalid protocolVersion, exiting.")
  exit(1)

##########################################################################
# msgType: type of the message (UINT16)
# pduType: pd/md
##########################################################################

if (pduType == "pd"):

  if ((args.msgTypePd == "5064") or (args.msgTypePd == "5065") or (args.msgTypePd == "5070") or (args.msgTypePd == "5072")):
    msgTypeStr = str(args.msgTypePd)
  else:
    print("ERROR: invalid msgTypePd, exiting.")
    exit(1)

elif (pduType == "md"):

  if ((args.msgTypeMd == "4d63") or (args.msgTypeMd == "4d65") or (args.msgTypeMd == "4d6e") or (args.msgTypeMd == "4d70") or (args.msgTypeMd == "4d71") or (args.msgTypeMd == "4d72")): 
    msgTypeStr = str(args.msgTypeMd)
  else:
    print("ERROR: invalid msgTypeMd, exiting.")
    exit(1)

else:
  print("ERROR: internal error at args.msgType, exiting.")
  exit(1)

msgTypeInt = int(msgTypeStr, 16)
msgTypeBin = bin(msgTypeInt)[2:].zfill(16)

# dictionary
pduDict.update({'msgTypeStr' : msgTypeStr})
pduDict.update({'msgTypeBin' : msgTypeBin})

# add the msgTYpe description
msgTypeDesc = get_desc(msgTypeDescDict, msgTypeStr)
pduDict.update({'msgTypeDesc' : msgTypeDesc})

##########################################################################
# comId: communication identifier (UINT32)
# pduType: pd/md
##########################################################################

if ((args.comId >= SMALLEST_UINT32) and (args.comId <= LARGEST_UINT32)):
  comIdBin = bin(args.comId)[2:].zfill(32)

  # dictionary
  pduDict.update({'comIdInt' : args.comId})
  pduDict.update({'comIdBin' : comIdBin})

  # add the comId description
  comIdDesc = get_desc(comIdDescDict, args.comId)
  pduDict.update({'comIdDesc' : comIdDesc})

else:
  print("ERROR: invalid comId, exiting.")
  exit(1)

##########################################################################
# topoCount: topoCount value (UINT32)
# pduType: pd/md
##########################################################################

if (pduDict['trdpVersion'] == 0):
  if ((args.topoCount >= SMALLEST_UINT32) and (args.topoCount <= LARGEST_UINT32)):
    topoCountBin = bin(args.topoCount)[2:].zfill(32)
    # dictionary
    pduDict.update({'topoCountInt' : args.topoCount})
    pduDict.update({'topoCountBin' : topoCountBin})
  else:
    print("ERROR: invalid topoCount, exiting.")
    exit(1)

##########################################################################
# etbTopoCnt: etbTopoCnt value (UINT32)
# pduType: pd/md
##########################################################################

if (pduDict['trdpVersion'] == 1):
  if ((args.etbTopoCnt >= SMALLEST_UINT32) and (args.etbTopoCnt <= LARGEST_UINT32)):
    etbTopoCntBin = bin(args.etbTopoCnt)[2:].zfill(32)
    # dictionary
    pduDict.update({'etbTopoCntInt' : args.etbTopoCnt})
    pduDict.update({'etbTopoCntBin' : etbTopoCntBin})
  else:
    print("ERROR: invalid etbTopoCnt, exiting.")
    exit(1)

##########################################################################
# opTrnTopoCnt: opTrnTopoCnt value (UINT32)
# pduType: pd/md
##########################################################################

if (pduDict['trdpVersion'] == 1):
  if ((args.opTrnTopoCnt >= SMALLEST_UINT32) and (args.opTrnTopoCnt <= LARGEST_UINT32)):
    opTrnTopoCntBin = bin(args.opTrnTopoCnt)[2:].zfill(32)
    # dictionary
    pduDict.update({'opTrnTopoCntInt' : args.opTrnTopoCnt})
    pduDict.update({'opTrnTopoCntBin' : opTrnTopoCntBin})
  else:
    print("ERROR: invalid opTrnTopoCnt, exiting.")
    exit(1)

##########################################################################
# datasetLength: length of the array 'dataset' in bytes (UINT32)
# pduType: pd/md
##########################################################################

datasetLengthInt = int(len(pduDict['datasetStr']) / 8)
datasetLengthBin = bin(datasetLengthInt)[2:].zfill(32)

# dictionary 
pduDict.update({'datasetLengthInt' : datasetLengthInt})
pduDict.update({'datasetLengthBin' : datasetLengthBin})

##########################################################################
# pduType: pd
##########################################################################

if (pduType == "pd"):

  ##########################################################################
  # reserved01: reserved for future use (=0) (UINT32)
  # pduType: pd
  ##########################################################################

  reserved01Int = 0

  if (pduDict['trdpVersion'] == 0):
    reserved01Bin = bin(reserved01Int)[2:].zfill(64)
  elif (pduDict['trdpVersion'] == 1):
    reserved01Bin = bin(reserved01Int)[2:].zfill(32)

  # dictionary
  pduDict.update({'reserved01Int' : reserved01Int})
  pduDict.update({'reserved01Bin' : reserved01Bin})

  ##########################################################################
  # replyComId: requested communication identifier (UINT32)
  # pduType: pd
  ##########################################################################

  if (pduDict['trdpVersion'] == 1):
    if ((args.replyComId >= SMALLEST_UINT32) and (args.replyComId <= LARGEST_UINT32)):
      replyComIdBin = bin(args.replyComId)[2:].zfill(32)
      # dictionary
      pduDict.update({'replyComIdInt' : args.replyComId})
      pduDict.update({'replyComIdBin' : replyComIdBin})
    else:
      print("ERROR: invalid replyComId, exiting.")
      exit(1)

  ##########################################################################
  # replyIpAddress: reply ip address (UINT32)
  # pduType: pd
  ##########################################################################

  if (validate_ip_address(args.replyIpAddress)):
    replyIpAddressInt = int(ipaddress.ip_address(args.replyIpAddress))
    replyIpAddressBin = bin(replyIpAddressInt)[2:].zfill(32)

    # dictionary
    pduDict.update({'replyIpAddressStr' : args.replyIpAddress})
    pduDict.update({'replyIpAddressBin' : replyIpAddressBin})
  else:
    print("ERROR: invalid replyIpAddress, exiting.")
    exit(1)

##########################################################################
# pduType: md
##########################################################################

elif (pduType == "md"):

  ##########################################################################
  # replyStatus: reply status indication (INT32)
  # pduType: md
  ##########################################################################

  if ((args.replyStatus >= SMALLEST_INT32) and (args.replyStatus <= LARGEST_INT32)):

    if (args.replyStatus < 0):
      replyStatusBin = bin(args.replyStatus % (1<<32))[2:]
    else:
      replyStatusBin = bin(args.replyStatus)[2:].zfill(32)

    # dictionary
    pduDict.update({'replyStatusInt' : args.replyStatus})
    pduDict.update({'replyStatusBin' : replyStatusBin})

    # add the replyStatus description
    if (args.replyStatus == 0):
      replyStatusDesc = "OK"
    elif (args.replyStatus > 0):
      replyStatusDesc = "user reply status"
    elif (args.replyStatus < 0):
      replyStatusDesc = "NOK: "
      replyStatusDesc = replyStatusDesc + get_desc(replyStatusDescDict, args.replyStatus)
    pduDict.update({'replyStatusDesc' : replyStatusDesc})

  else:
    print("ERROR: invalid replyStatus, exiting.")
    exit(1)

  ##########################################################################
  # sessionId: session identifier (UINT32[4])
  # pduType: md
  ##########################################################################

  if (args.sessionId):
    if (is_uuid(args.sessionId)):
      sessionIdStr = args.sessionId
    else:
      print("ERROR: invalid sessionId, exiting.")
      exit(1)
  else:
    # generate a random uuid in hex (without separators)
    sessionIdStr = uuid.uuid1().hex

  sessionIdInt = int(sessionIdStr, 16)
  sessionIdBin = bin(sessionIdInt)[2:].zfill(128)

  # dictionary
  pduDict.update({'sessionIdStr' : sessionIdStr})
  pduDict.update({'sessionIdBin' : sessionIdBin})

  ##########################################################################
  # replyTimeout: reply timeout (UINT32)
  # pduType: md
  ##########################################################################

  if ((args.replyTimeout >= SMALLEST_UINT32) and (args.replyTimeout <= LARGEST_UINT32)):
    replyTimeoutBin = bin(args.replyTimeout)[2:].zfill(32)

    # dictionary
    pduDict.update({'replyTimeoutInt' : args.replyTimeout})
    pduDict.update({'replyTimeoutBin' : replyTimeoutBin})
  else:
    print("ERROR: invalid replyTimeout, exiting.")
    exit(1)

  ##########################################################################
  # sourceURI: source URI - user part (CHAR[32])
  # pduType: md
  ##########################################################################

  if ((len(args.sourceURI) >= 0) and (len(args.sourceURI) <= 31)):
    sourceURIBin = generate_uri(args.sourceURI)
  else:
    print("ERROR: invalid sourceURI, exiting.")
    exit(1)

  # dictionary
  pduDict.update({'sourceURIStr' : args.sourceURI})
  pduDict.update({'sourceURIBin' : sourceURIBin})

  ##########################################################################
  # destinationURI: destination URI - user part (CHAR[32])
  # pduType: md
  ##########################################################################

  if ((len(args.destinationURI) >= 0) and (len(args.destinationURI) <= 31)):
    destinationURIBin = generate_uri(args.destinationURI)
  else:
    print("ERROR: invalid destinationURI, exiting.")
    exit(1)

  # dictionary
  pduDict.update({'destinationURIStr' : args.destinationURI})
  pduDict.update({'destinationURIBin' : destinationURIBin})

##########################################################################
# invalid pdu type
##########################################################################

else:
  print("ERROR: internal error when evaluating pduType, exiting.")
  exit(1)

##########################################################################
# assemble the pdu header
##########################################################################

# pd/md header: common fields
pduDict.update({'headerBin' : sequenceCounterBin + protocolVersionBin + msgTypeBin + comIdBin})
if (pduDict['trdpVersion'] == 0):
  pduDict.update({'headerBin' : pduDict['headerBin'] + topoCountBin})
elif (pduDict['trdpVersion'] == 1):
  pduDict.update({'headerBin' : pduDict['headerBin'] + etbTopoCntBin + opTrnTopoCntBin})
pduDict.update({'headerBin' : pduDict['headerBin'] + datasetLengthBin})

# pd header
if (pduType == "pd"):
  pduDict.update({'headerBin' : pduDict['headerBin'] + reserved01Bin})
  if (pduDict['trdpVersion'] == 1):
    pduDict.update({'headerBin' : pduDict['headerBin'] + replyComIdBin})
  pduDict.update({'headerBin' : pduDict['headerBin'] + replyIpAddressBin})

# md header
elif (pduType == "md"):
  pduDict.update({'headerBin' : pduDict['headerBin'] + \
                                replyStatusBin       + \
                                sessionIdBin         + \
                                replyTimeoutBin      + \
                                sourceURIBin         + \
                                destinationURIBin})
else:
  print("ERROR: internal error when evaluating pduType, exiting.")
  exit(1)

# dictionary
pduDict.update({'headerBinLength' : len(pduDict['headerBin'])})

##########################################################################
# generate the dataset
##########################################################################

# generate the dataset
datasetBin, datasetPaddingLength = generate_dataset(pduDict['datasetStr'])

# dictionary
pduDict.update({'datasetBin' : datasetBin})
pduDict.update({'datasetBinLength' : len(datasetBin)})
pduDict.update({'datasetPaddingLength' : datasetPaddingLength})

##########################################################################
# headerFcs: header checksum (UINT32)
##########################################################################

# generate the fcs
if (pduDict['trdpVersion'] == 0):
  # fcs is computed using the entire pdu (excluding the fcs field)
  fcsHex, fcsBin = generate_fcs(pduDict['headerBin'] + pduDict['datasetBin'], pduDict['trdpVersion'])
elif (pduDict['trdpVersion'] == 1):
  # fcs is computed using the header only (excluding the fcs field)
  fcsHex, fcsBin = generate_fcs(pduDict['headerBin'], pduDict['trdpVersion'])

# dictionary
pduDict.update({'fcsHex' : fcsHex})
pduDict.update({'fcsBin' : fcsBin})
pduDict.update({'fcsBinLength' : len(fcsBin)})

##########################################################################
# assemble the pdu
##########################################################################

# assemble the pdu
if (pduDict['trdpVersion'] == 0):
  pduDict['pduBin'] = pduDict['headerBin'] + pduDict['datasetBin'] + pduDict['fcsBin'] 
elif (pduDict['trdpVersion'] == 1):
  pduDict['pduBin'] = pduDict['headerBin'] + pduDict['fcsBin'] + pduDict['datasetBin']
pduDict['pduBinLength'] = len(pduDict['pduBin'])

# sanity check the pdu 
if (not is_byte_sequence(pduDict['pduBin'])):
  print(f"ERROR: invalid PDU, exiting.")
  exit(1)

##########################################################################
# send the pdu
##########################################################################

# convert the pdu into bytes
pduBytes = bytes((int(pduDict['pduBin'][i:i+8], 2) for i in range(0, len(pduDict['pduBin']), 8)))

if (pduDict['protocolName'] == "udp"):
  # construct and sent the packet: scapy (user can set the srcMacAddr, srcInetAddr or srcPort)
  trdpPacket = Ether(src=pduDict['srcMacAddr'])/IP(src=pduDict['srcInetAddr'], dst=pduDict['dstInetAddr'])/UDP(sport=pduDict['srcPort'], dport=pduDict['dstPort'])/Raw(pduBytes)
  sendp(trdpPacket, iface="eth0", verbose=False)
elif (pduDict['protocolName'] == "tcp"):
  # construct and sent the packet: socket (user cannot set the srcMacAddr, srcInetAddr or srcPort)
  socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM, 0)
  socket.connect((pduDict['dstInetAddr'], pduDict['dstPort']))
  srcInetAddr, srcPort = socket.getsockname()
  socket.send(pduBytes)
else:
  print("ERROR: internal error when evaluating protocol, exiting.")
  exit(1)

# timestamp
timestamp = time.time()
timestamp = str(timestamp) + "00"
pduDict.update({'timestamp' : timestamp})

##########################################################################
# print output
##########################################################################

print_pdu(pduDict, args.verbose)

##########################################################################
# end
##########################################################################
