#!/usr/bin/python3
  
##########################################################################
# trdpdump.py
#
# Version: 2.16
#
#
# Process TRDP PDUs.
#
# PD Protocol: UDP
# PD Port:     17224
# Reference :  Appendix A.6 Process Data (p126)
# Packet:      Figure A.11 (p132)
#
# MD Protocol: UDP / TCP
# MD Port:     17225 (UDP) / 17226 (TCP)
# Reference:   Appendix A.7 Message Data (p146)
# Packet:      Figure A.19 (p148)
#
# Packet formats defined in:
#
# BS EN 61375-2-3:2015+A11:2017 Electronic railway equipment -
# Train communication network (TCN). Part 2-3 TCN communication profile
# (IEC 61375-2-3:2015).
# BS EN 61375-2-3-2015+A11-2017--[2023-06-30--06-08-39 PM].pdf
#
# And:
#
# West Coast Partnership TMS for AT300 Ethernet Communication Interface
# Specification, Mito Works Drawing Number 365-3E857140, Hitachi Limited,
# 01/02/2021.
# 3E857140Rv01_WCP_Ethernet_Communication_Interface_Specification.pdf
#
# python3 module dependencies: see trdp.py
#
##########################################################################

import argparse
import binascii
import os
import sys

from bitstring import BitArray
from datetime import datetime
from scapy.all import *
from trdp_include import *

##########################################################################
# global variables
##########################################################################

outputFileName = "trdpdump_" + str(datetime.now().isoformat())

captureMode = "sniff"
writeTxtFiles = False
writePcapFile = False

##########################################################################
# dictionaries
##########################################################################

pduDict = {}

##########################################################################
# ensure the user has root privileges
##########################################################################

if (os.geteuid() != 0):
  print("ERROR: you need root privileges to run this script, exiting.")
  exit(1)

##########################################################################
# parse arguments
##########################################################################

# create parser
parser = argparse.ArgumentParser(description="Process a PCAP file containing TRDP packets.")

# add arguments to parser
parser.add_argument("-v", "--verbose", default=False, required=False, action="store_true", help="Increase output verbosity.")
parser.add_argument("-t", "--trdpVersion", type=int, required=False, default=1, help="TRDP version. Valid: 0 (Hitachi WCP TMS for AT300 365-3E857140, Hitachi Class 800-807); 1 (IEC 61375-2-3:2015, Hitachi Class 810). Default: 1.")
parser.add_argument("-f", "--bpfFilter", default="", required=False, type=str, help="BPF filter.")
parser.add_argument("-r", "--readPcapFile", type=str, required=False, help="PCAP input file.")
parser.add_argument("-wt", "--writeTxtFiles", default=False, required=False, action="store_true", help="Write CVS and JSON output files.")
parser.add_argument("-wp", "--writePcapFile", default=False, required=False, action="store_true", help="Write a PCAP output file.")

# retrieve args 
args = parser.parse_args()

##########################################################################
# process arguments
##########################################################################"

# bpfFilter
if (args.bpfFilter):
  bpfFilter = args.bpfFilter
else:
  bpfFilter = ""

# trdpVersion
if ((args.trdpVersion >= 0) and (args.trdpVersion <= 1)):
  trdpVersion = args.trdpVersion
else:
  print(f"ERROR: invalid TRDP version, exiting.")
  exit(1)

# readPcapFile
if (args.readPcapFile):
  if (os.path.exists(args.readPcapFile)):
    captureMode = "read"
    pcapInputFile = args.readPcapFile
  else:
    print("ERROR: PCAP input file not found, exiting.")
    exit(1)
else:
  captureMode = "sniff"

# writePcapFile
if (args.writePcapFile):
  writePcapFile = True
  os.makedirs(outputFileName, exist_ok=True)
  pcapFileName = outputFileName + "/" + outputFileName + ".pcap"

# writeTxtFiles
if (args.writeTxtFiles):
  writeTxtFiles = True
  os.makedirs(outputFileName, exist_ok=True)
  txtFileName = outputFileName + "/" + outputFileName

##########################################################################
# process_packet funcion: start
##########################################################################

def process_packet(packet):

  try:

    # global variables
    global packetCountTotal
    global packetCountPd
    global packetCountMd
    global packetCountUnknown
    global packetCountInvalid
    global packetCountFcsInvalid

    # increment packetCountTotal
    packetCountTotal += 1

    # marker to indicate whether the packet is valid
    VALID_PACKET = True

    # pdu dictionary: contains data required to display the pdu
    pduDict = {}

    # initial values
    pduDict.update({'packetCount'  : packetCountTotal})
    pduDict.update({'packetStatus' : "received"})

    # extracted from the packet
    pduDict.update({'timestamp'      : str(packet.time)})
    pduDict.update({'protocolNumber' : packet[IP].proto})
    pduDict.update({'protocolName'   : "udp"})
    pduDict.update({'srcMacAddr'     : packet[Ether].src.upper()})
    pduDict.update({'dstMacAddr'     : packet[Ether].dst.upper()})
    pduDict.update({'srcInetAddr'    : packet[IP].src})
    pduDict.update({'dstInetAddr'    : packet[IP].dst})
    pduDict.update({'srcPort'        : packet[UDP].sport})
    pduDict.update({'dstPort'        : packet[UDP].dport})
    pduDict.update({'trdpVersion'    : trdpVersion})

    # udp payload
    udpPayloadBytes = bytes(packet[UDP].payload)
    udpPayloadHex = binascii.hexlify(bytes(packet[UDP].payload)).decode()
    pduDict.update({'pduHex' : udpPayloadHex})

    # calculated from the above
    #
    pduDict.update({'pduHexLength'    : int(len(pduDict['pduHex'])/2)})
    pduDict.update({'pduBin'          : ''.join(bin(int(c, 16))[2:].zfill(4) for c in pduDict['pduHex'])})
    pduDict.update({'pduBinLength'    : int(len(pduDict['pduBin']))})
    pduDict.update({'trdpVersionDesc' : get_desc(trdpVersionDict, pduDict['trdpVersion'])})
    # 
    # frame and packet lengths
    pduDict.update({'ethernetFrameLength' : len(packet[Ether])})
    pduDict.update({'ipPacketLength'      : packet[IP].len})
    pduDict.update({'udpPacketLength'     : packet[UDP].len})

    # ip address information
    #
    # currently only for TRDP version 0
    if (pduDict['trdpVersion'] == 0):
      pduDict.update({'srcInetAddrDetails' : process_hitachi_ip_address(pduDict['srcInetAddr'])})
      pduDict.update({'dstInetAddrDetails' : process_hitachi_ip_address(pduDict['dstInetAddr'])})

    ##########################################################################
    # sanity check the packet to ensure it is a valid pdu
    ##########################################################################

    # establish whether the pd/md pdu must be of a valid length

    if (pduDict['pduBinLength'] > MD_PDU_MAX_LENGTH_BITS):
      # pdu is too long
      VALID_PACKET = False
    elif ((pduDict['trdpVersion'] == 0) and (pduDict['pduBinLength'] < DRAFT_PD_PDU_MIN_LENGTH_BITS)):
      # pdu is too short
      VALID_PACKET = False
    elif ((pduDict['trdpVersion'] == 1) and (pduDict['pduBinLength'] < STD_PD_PDU_MIN_LENGTH_BITS)):
      # pdu is too short
      VALID_PACKET = False

    if (VALID_PACKET == False):
      print_received_pdu_error("PDU length is invalid (" + str(pduDict['pduBinLength']) + "-bits), ignoring (#" + str(pduDict['packetCount']) + ")")
      packetCountInvalid += 1
      return

    ##########################################################################
    # pd/md header
    ##########################################################################

    # although not the first header, determine the msgType first so we can
    # establish whether the pdu is valid

    ##########################################################################
    # msgType: type of the message (UINT16)
    # pduType: pd/md
    ##########################################################################

    msgTypeBin = pduDict['pduBin'][48:64]
    msgTypeInt = int(msgTypeBin, 2)
    msgTypeHex = hex(msgTypeInt)
    msgTypeStr = msgTypeHex[2:].zfill(4).lower()
    pduDict.update({'msgTypeStr' : msgTypeStr})
    pduDict.update({'msgTypeBin' : msgTypeBin})

    # determine pduType from the msgType
    if ((msgTypeStr == "5064") or (msgTypeStr == "5065") or (msgTypeStr == "5070") or (msgTypeStr == "5072")):
      pduType = "pd"
    elif ((msgTypeStr == "4d63") or (msgTypeStr == "4d65") or (msgTypeStr == "4d6e") or (msgTypeStr == "4d70") or (msgTypeStr == "4d71") or (msgTypeStr == "4d72")):
      pduType = "md"
    else:
      pduType = "unknown"

    # add the msgType description
    msgTypeDesc = get_desc(msgTypeDescDict, msgTypeStr)
    pduDict.update({'msgTypeDesc' : msgTypeDesc})

    # add the pduType (determined by the msgType)
    pduDict.update({'pduType' : pduType})

    ##########################################################################
    # pduType: pd/md
    ##########################################################################

    if ((pduType == "pd") or (pduType == "md")):

      ##########################################################################
      # sequenceCounter: message sequence counter (UINT32)
      # pduType: pd/md
      ##########################################################################

      sequenceCounterBin = pduDict['pduBin'][0:32]
      sequenceCounterInt = int(sequenceCounterBin, 2)
      sequenceCounterHex = int(sequenceCounterBin, 2)
      pduDict.update({'sequenceCounterInt' : sequenceCounterInt})
      pduDict.update({'sequenceCounterBin' : sequenceCounterBin})
      pduDict.update({'sequenceCounterHex' : sequenceCounterHex})

      ##########################################################################
      # protocolVersion: protocol version (UINT16)
      # pduType: pd/md
      ##########################################################################

      protocolVersionBin = pduDict['pduBin'][32:48]
      protocolVersionMain = int(protocolVersionBin[0:8], 2)
      protocolVersionSub = int(protocolVersionBin[8:16], 2)
      protocolVersionStr = str(protocolVersionMain) + "." + str(protocolVersionSub)
      protocolVersionHex = hex(protocolVersionMain)[2:].zfill(2) + hex(protocolVersionSub)[2:].zfill(2)
      pduDict.update({'protocolVersionStr' : protocolVersionStr})
      pduDict.update({'protocolVersionBin' : protocolVersionBin})
      pduDict.update({'protocolVersionHex' : protocolVersionHex})
      
      ##########################################################################
      # comId: communication identifier (UINT32)
      # pduType: pd/md
      ##########################################################################

      comIdBin = pduDict['pduBin'][64:96]
      comIdInt = int(comIdBin, 2)
      pduDict.update({'comIdInt' : comIdInt})
      pduDict.update({'comIdBin' : comIdBin})

      # add the comId description
      comIdDesc = get_desc(comIdDescDict, comIdInt)
      pduDict.update({'comIdDesc' : comIdDesc})

      ##########################################################################
      # topoCount: topoCount value (UINT32)
      # pduType: pd/md
      ##########################################################################

      if (pduDict['trdpVersion'] == 0):
        topoCountBin = pduDict['pduBin'][96:128]
        topoCountInt = int(topoCountBin, 2)
        pduDict.update({'topoCountInt' : topoCountInt})
        pduDict.update({'topoCountBin' : topoCountBin})

      ##########################################################################
      # etbTopoCnt: etbTopoCnt value (UINT32)
      # pduType: pd/md
      ##########################################################################

      if (pduDict['trdpVersion'] == 1):
        etbTopoCntBin = pduDict['pduBin'][96:128]
        etbTopoCntInt = int(etbTopoCntBin, 2)
        pduDict.update({'etbTopoCntInt' : etbTopoCntInt})
        pduDict.update({'etbTopoCntBin' : etbTopoCntBin})

      ##########################################################################
      # opTrnTopoCnt: opTrnTopoCnt value (UINT32)
      # pduType: pd/md
      ##########################################################################

      if (pduDict['trdpVersion'] == 1):
        opTrnTopoCntBin = pduDict['pduBin'][128:160]
        opTrnTopoCntInt = int(opTrnTopoCntBin, 2)
        pduDict.update({'opTrnTopoCntInt' : opTrnTopoCntInt})
        pduDict.update({'opTrnTopoCntBin' : opTrnTopoCntBin})

      ##########################################################################
      # datasetLength: length of the array 'dataset' in bytes (UINT32)
      # pduType: pd/md
      ##########################################################################

      if (pduDict['trdpVersion'] == 0):
        datasetLengthBin = pduDict['pduBin'][128:160]
      elif (pduDict['trdpVersion'] == 1):
        datasetLengthBin = pduDict['pduBin'][160:192]

      datasetLengthInt = int(datasetLengthBin, 2)
      pduDict.update({'datasetLengthInt' : datasetLengthInt})
      pduDict.update({'datasetLengthBin' : datasetLengthBin})

      ##########################################################################
      # pduType: pd
      ##########################################################################

      if (pduType == "pd"):

        ##########################################################################
        # sanity check the packet to ensure it is a valid pd pdu
        ##########################################################################

        # the pd pdu must be of a valid length
        if ((pduDict['trdpVersion'] == 0) and ((pduDict['pduBinLength'] < DRAFT_PD_PDU_MIN_LENGTH_BITS) or (pduDict['pduBinLength'] > PD_PDU_MAX_LENGTH_BITS))):
            VALID_PACKET = False
        elif ((pduDict['trdpVersion'] == 1) and ((pduDict['pduBinLength'] < STD_PD_PDU_MIN_LENGTH_BITS) or (pduDict['pduBinLength'] > PD_PDU_MAX_LENGTH_BITS))):
            VALID_PACKET = False

        if (VALID_PACKET == False):
          print_received_pdu_error("PD PDU length is invalid (" + str(pduDict['pduBinLength']) + "-bits), ignoring (#" + str(pduDict['packetCount']) + ")")
          packetCountInvalid += 1
          return

        ##########################################################################
        # reserved01: reserved for future use (=0) (UINT32)
        # pduType: pd
        ##########################################################################

        if (pduDict['trdpVersion'] == 0):
          reserved01Bin = pduDict['pduBin'][160:224]
        elif (pduDict['trdpVersion'] == 1):
          reserved01Bin = pduDict['pduBin'][192:224]

        reserved01Int = int(reserved01Bin ,2)
        pduDict.update({'reserved01Int' : reserved01Int})
        pduDict.update({'reserved01Bin' : reserved01Bin})

        ##########################################################################
        # replyComId: requested communication identifier (UINT32)
        # pduType: pd
        ##########################################################################

        if (pduDict['trdpVersion'] == 1):
          replyComIdBin = pduDict['pduBin'][224:256]
          replyComIdInt = int(replyComIdBin, 2)
          pduDict.update({'replyComIdInt' : replyComIdInt})
          pduDict.update({'replyComIdBin' : replyComIdBin})

        ##########################################################################
        # replyIpAddress: reply ip address (UINT32)
        # pduType: pd
        ##########################################################################

        if (pduDict['trdpVersion'] == 0):
          replyIpAddressBin = pduDict['pduBin'][224:256]
        elif (pduDict['trdpVersion'] == 1):
          replyIpAddressBin = pduDict['pduBin'][256:288]

        replyIpAddressInt = int(replyIpAddressBin, 2)
        replyIpAddressStr = str(ipaddress.ip_address(replyIpAddressInt))
        pduDict.update({'replyIpAddressStr' : replyIpAddressStr})
        pduDict.update({'replyIpAddressBin' : replyIpAddressBin})

      ##########################################################################
      # pduType: md
      ##########################################################################

      elif (pduType == "md"):

        ##########################################################################
        # sanity check the packet to ensure it is a valid md pdu
        ##########################################################################

        # the pd pdu must be of a valid length
        if ((pduDict['trdpVersion'] == 0) and ((pduDict['pduBinLength'] < DRAFT_MD_PDU_MIN_LENGTH_BITS) or (pduDict['pduBinLength'] > MD_PDU_MAX_LENGTH_BITS))):
            VALID_PACKET = False
        elif ((pduDict['trdpVersion'] == 1) and ((pduDict['pduBinLength'] < STD_MD_PDU_MIN_LENGTH_BITS) or (pduDict['pduBinLength'] > MD_PDU_MAX_LENGTH_BITS))):
            VALID_PACKET = False

        if (VALID_PACKET == False):
          print_received_pdu_error("MD PDU length is invalid (" + str(pduDict['pduBinLength']) + "-bits), ignoring (#" + str(pduDict['packetCount']) + ")")
          packetCountInvalid += 1
          return

        ##########################################################################
        # replyStatus: reply status indication (INT32)
        # pduType: md
        ##########################################################################

        if (pduDict['trdpVersion'] == 0):
          replyStatusBin = pduDict['pduBin'][160:192]
        elif (pduDict['trdpVersion'] == 1):
          replyStatusBin = pduDict['pduBin'][192:224]

        replyStatusHex = BitArray(bin=replyStatusBin) # perform two's compliment on the signed integer
        replyStatusInt = replyStatusHex.int

        pduDict.update({'replyStatusInt' : replyStatusInt})
        pduDict.update({'replyStatusBin' : replyStatusBin})

        # add the replyStatus description
        if (replyStatusInt == 0):
          replyStatusDesc = "OK"
        elif (replyStatusInt > 0):
          replyStatusDesc = "user reply status"
        elif (replyStatusInt < 0):
          replyStatusDesc = "NOK: "
          replyStatusDesc = replyStatusDesc + get_desc(replyStatusDescDict, replyStatusInt)
        pduDict.update({'replyStatusDesc' : replyStatusDesc})

        ##########################################################################
        # sessionId: session identifier (UINT32[4])
        # pduType: md
        ##########################################################################

        if (pduDict['trdpVersion'] == 0):
          sessionIdBin = pduDict['pduBin'][192:320]
        elif (pduDict['trdpVersion'] == 1):
          sessionIdBin = pduDict['pduBin'][224:352]

        sessionId1 = str(hex(int(sessionIdBin[0:32], 2))[2:].zfill(8))
        sessionId2 = str(hex(int(sessionIdBin[32:64], 2))[2:].zfill(8))
        sessionId3 = str(hex(int(sessionIdBin[64:96], 2))[2:].zfill(8))
        sessionId4 = str(hex(int(sessionIdBin[96:128], 2))[2:].zfill(8))

        sessionIdStr = sessionId1 + sessionId2 + sessionId3 + sessionId4
        pduDict.update({'sessionIdStr' : sessionIdStr})
        pduDict.update({'sessionIdBin' : sessionIdBin})

        ##########################################################################
        # replyTimeout: reply timeout (UINT32)
        # pduType: md
        ##########################################################################

        if (pduDict['trdpVersion'] == 0):
          replyTimeoutBin = pduDict['pduBin'][320:352]
        if (pduDict['trdpVersion'] == 1):
          replyTimeoutBin = pduDict['pduBin'][352:384]

        replyTimeoutInt = int(replyTimeoutBin, 2)
        pduDict.update({'replyTimeoutInt' : replyTimeoutInt})
        pduDict.update({'replyTimeoutBin' : replyTimeoutBin})

        ##########################################################################
        # sourceURI: source URI - user part (CHAR[32])
        # pduType: md
        ##########################################################################

        if (pduDict['trdpVersion'] == 0):
          sourceURIBin = pduDict['pduBin'][352:608]
        elif (pduDict['trdpVersion'] == 1):
          sourceURIBin = pduDict['pduBin'][384:640]

        # convert the binary string into bytes
        sourceURIBytes = bytes((int(sourceURIBin[i:i+8], 2) for i in range(0, len(sourceURIBin), 8)))

        # extract the uri from the beginning of the null bytes
        sourceURIStrBytes = sourceURIBytes.split(b'\x00')[0]

        # decode the bytes into ascii
        sourceURIStr = sourceURIStrBytes.decode('ascii')

        pduDict.update({'sourceURIStr' : sourceURIStr})
        pduDict.update({'sourceURIBin' : sourceURIBin})

        ##########################################################################
        # destinationURI: destination URI - user part (CHAR[32])
        # pduType: md
        ##########################################################################

        if (pduDict['trdpVersion'] == 0):
          destinationURIBin = pduDict['pduBin'][608:864]
        elif (pduDict['trdpVersion'] == 1):
          destinationURIBin = pduDict['pduBin'][640:896]

        # convert the binary string into bytes
        destinationURIBytes = bytes((int(destinationURIBin[i:i+8], 2) for i in range(0, len(destinationURIBin), 8)))

        # extract the uri from the beginning of the null bytes
        destinationURIStrBytes = destinationURIBytes.split(b'\x00')[0]

        # decode the bytes into ascii
        destinationURIStr = destinationURIStrBytes.decode('ascii')

        pduDict.update({'destinationURIStr' : destinationURIStr})
        pduDict.update({'destinationURIBin' : destinationURIBin})

      ##########################################################################
      # invalid pdu type
      ##########################################################################

      else:
        print("ERROR: internal error when evaluating pduType, exiting.")
        exit(1)

      ##########################################################################
      # fcs and dataset calculations
      ##########################################################################

      # the number of bits in the dataset (without padding)
      datasetStrLength = datasetLengthInt * 8

      # calculate fcs and dataset locations
      if (pduDict['trdpVersion'] == 0):
        if (pduType == "pd"):
          datasetBegin = 256
        elif (pduType == "md"):
          datasetBegin = 864
        fcsBegin = pduDict['pduBinLength'] - 32 # the fcs is the last 4-bytes/32-bits of the pdu

      elif (pduDict['trdpVersion'] == 1):
        if (pduType == "pd"):
          datasetBegin = 320
        elif (pduType == "md"):
          datasetBegin = 928
        fcsBegin = datasetBegin - 32 # the fcs is the 4-bytes/32-bits before the dataset

      # common values pertaining to those above
      datasetEnd = datasetBegin + datasetStrLength
      fcsEnd = fcsBegin + 32

      # dictionary
      pduDict.update({'datasetBegin' : datasetBegin})
      pduDict.update({'datasetEnd'   : datasetEnd})
      pduDict.update({'fcsBegin'     : fcsBegin})
      pduDict.update({'fcsEnd'       : fcsEnd})

      ##########################################################################
      # dataset: UINT8[datasetLength]
      ##########################################################################

      # the dataset without the padding
      datasetStr = pduDict['pduBin'][datasetBegin:datasetEnd]

      # if datasetLengthInt is zero, datasetStrLength will also be zero (because datasetLength is not in the correct format)
      # in this case, ignore the datasetLength and terminate the dataset at the end of the pdu
      if (datasetStr == ""):
        datasetStr = pduDict['pduBin'][datasetBegin:]

      # the added padding
      datasetPaddingLength = calculate_num_dataset_padding_bytes(datasetStr)

      # dictionary
      pduDict.update({'datasetStr' : datasetStr})
      pduDict.update({'datasetStrLength' : len(datasetStr)})
      pduDict.update({'datasetPaddingLength' : datasetPaddingLength})

      # datasetHex
      datasetHex = generate_dataset_hex(datasetStr)
      pduDict.update({'datasetHex' : datasetHex})
      pduDict.update({'datasetHexLength' : len(datasetHex)})

      ##########################################################################
      # dataset: disection to extract SDR data
      ##########################################################################

      if ((pduType == "pd") and (pduDict['msgTypeStr'] == "5072") and (pduDict['trdpVersion'] == 0)): 

          if ((pduDict['dstInetAddr'] == "239.1.1.20") or (pduDict['dstInetAddr'] == "239.2.1.20")):
            # Common Data (Safety) for:
            #   CSV-SDR1: 239.1.1.20 (System 1)
            #   CSV-SDR1: 239.2.1.20 (System 2)
            pduDict.update({'pdSdrDetails' : process_hitachi_pd_sdr(pduDict['datasetStr'], 0)})

          elif ((pduDict['dstInetAddr'] == "239.3.2.10") or (pduDict['dstInetAddr'] == "239.3.2.20") or (pduDict['dstInetAddr'] == "239.3.2.22")):
            # Common Data (Non-Safety) for:
            #   MLC-SDR1: 239.3.2.10 (System 2)
            #   MLV-SDR1: 239.3.2.20 (System 2)
            #   MLV-SDR3: 239.3.2.22 (System 2)
            pduDict.update({'pdSdrDetails' : process_hitachi_pd_sdr(pduDict['datasetStr'], 1)})

      ##########################################################################
      # fcs: (UINT32)
      ##########################################################################

      # extract the fcs from the pdu
      fcsBin = pduDict['pduBin'][fcsBegin:fcsEnd]
      fcsInt = int(fcsBin, 2)
      fcsHex = hex(fcsInt)
      fcsStr = fcsHex[2:].lower()

      # dictionary
      pduDict.update({'fcsHex' : fcsStr})
      pduDict.update({'fcsBin' : fcsBin})
      pduDict.update({'fcsBinLength' : len(fcsBin)})

      # the data that is to be included in the crc32 computation (i.e. all that placed before the fcs)
      dataToFcsBin = pduDict['pduBin'][0:fcsBegin]

      # validate the fcs
      headerComputedFcsHex, HeaderComputedFcsBin = generate_fcs(dataToFcsBin, pduDict['trdpVersion'])

      # dictionary
      pduDict.update({'headerComputedFcsHex' : headerComputedFcsHex})

      if (fcsStr == headerComputedFcsHex):
        pduDict.update({'fcsValid' : True})
      else:
        pduDict.update({'fcsValid' : False})
        packetCountFcsInvalid += 1

    ##########################################################################
    # pduType: unknown
    ##########################################################################

    # dump the entire unknown pdu as the dataset

    elif (pduType == "unknown"):

      datasetStr = pduDict['pduBin'][0:]

      # dictionary
      pduDict.update({'datasetStr' : datasetStr})
      pduDict.update({'datasetLengthInt' : len(datasetStr)})

    ##########################################################################
    # invalid pdu type
    ##########################################################################

    else:
      print("ERROR: internal error when evaluating pduType, exiting.")
      exit(1)

    ##########################################################################
    # write output to files, if required
    ##########################################################################

    # pcap
    if (writePcapFile == True):
      wrpcap(pcapFileName, packet, append=True)

    # text
    if (writeTxtFiles == True):
      write_txt_output_files(pduDict, txtFileName)

    ##########################################################################
    # update counters
    ##########################################################################

    if (pduType == "pd"):
      packetCountPd += 1
    elif (pduType == "md"):
      packetCountMd += 1
    elif (pduType == "unknown"):
      packetCountUnknown += 1

    ##########################################################################
    # fingerprint
    ##########################################################################

    pduDict.update({'fingerprint' : generate_fingerprint(pduDict)})

    ##########################################################################
    # print output
    ##########################################################################

    print_pdu(pduDict, args.verbose)

    ##########################################################################
    # process_packet funcion: finish
    ##########################################################################

  except Exception:
    # prevent packets from breaking the processor
    print_received_pdu_error("exception thrown by processor, ignoring (#" + str(pduDict['packetCount']) + ")")
    packetCountInvalid += 1

##########################################################################
# main
##########################################################################

# counters
packetCountTotal = 0
packetCountPd = 0
packetCountMd = 0
packetCountUnknown = 0
packetCountInvalid = 0
packetCountFcsInvalid = 0

##########################################################################
# sniff or read the packets
##########################################################################

if (captureMode == "sniff"):
  print("Ready.")
  capture = sniff(prn=process_packet, filter=bpfFilter)
elif (captureMode == "read"):
  for packet in rdpcap(pcapInputFile):
    process_packet(packet)
else:
  print("ERROR: invalid captureMode, exiting.")
  exit(1)

##########################################################################
# print output
##########################################################################

print("==========================================================================")
print(f"Valid TRDP UDP PD PDU Packets Processed : {packetCountPd}")
print(f"Valid TRDP UDP MD PDU Packets Processed : {packetCountMd}")
print("--------------------------------------------------------------------------")
print(f"Unknown Packets Processed               : {packetCountUnknown}")
print(f"Invalid Packets Processed               : {packetCountInvalid}")
print("--------------------------------------------------------------------------")
print(f"Valid TRDP PDUs with an invalid FCS     : {packetCountFcsInvalid}", end="")
if (packetCountFcsInvalid > 0):
  print(" *")
else:
  print("")
print("--------------------------------------------------------------------------")
print(f"Total Packets Processed                 : {packetCountTotal}")
print("==========================================================================")

if (packetCountFcsInvalid > 0):
  if (trdpVersion == 0):
    tryTrdpVersion = 1
  else:
    tryTrdpVersion = 0
  print (f"* TRDP PDUs with an invalid FCS might be the result of an incorrect TRDP version. Try again with option: -t {tryTrdpVersion}")

##########################################################################
# end
##########################################################################
